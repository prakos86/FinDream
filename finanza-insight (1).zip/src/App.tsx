/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react'; 
import { auth, setCachedAccessToken } from './firebase';
import { GoogleAuthProvider, signInWithPopup, signInWithRedirect, getRedirectResult, onAuthStateChanged } from 'firebase/auth';
import { 
  TrendingUp, 
  TrendingDown, 
  Plus, 
  X, 
  Mic, 
  MicOff,
  AudioLines, 
  Home, 
  Utensils, 
  Car, 
  ShoppingBag, 
  Plane, 
  MoreHorizontal, 
  Trash2, 
  Smartphone, 
  Maximize2, 
  Minimize2, 
  Sparkles,
  Volume2,
  VolumeX,
  PlusCircle,
  Clock,
  Trash,
  Check,
  ChevronRight,
  Info,
  Cloud,
  Server,
  Database,
  User,
  CreditCard,
  Send,
  MessageSquare,
  Loader2,
  Globe,
  PieChart,
  Eye,
  EyeOff,
  Zap,
  Search,
  LogOut,
  Fingerprint,
  Shield,
  ShieldCheck,
  ScanFace,
  Heart,
  Scissors,
  Briefcase,
  Upload
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import * as XLSX from 'xlsx';
import { Categoria, TipoMovimiento, Transaccion, FiltroTiempo, Sueno, UserProfile, ProductoFinanciero, ChatMessage } from './types';
import { useFirestore } from './hooks/useFirestore';
import { useGoogleSheets } from './hooks/useGoogleSheets';
import { useSpeechRecognition } from './hooks/useSpeechRecognition';
import { DreamComplianceChart } from './components/DreamComplianceChart';
import { ChatPanel } from './components/ChatPanel';
import { TransactionForm } from './components/TransactionForm';
import { SplashIntro } from './components/SplashIntro';
import { FinDreamLogo } from './components/FinDreamLogo';
import { ProfileModal } from './components/ProfileModal';
import { PieChart as RechartsPieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

const TRANSLATIONS = {
  ES: {
    tab_resumen: "Resumen",
    tab_sueno: "Sueño",
    tab_insights: "Insights",
    ingresar_movimiento: "Ingresar a Finanzas",
    mi_cuenta: "Mi Cuenta",
    ingresos: "Activos / Ingresos",
    egresos: "Pasivos / Egresos",
    saldo_neto: "Saldo Neto",
    deuda: "Pasivos / Deudas",
    sincronizado: "Sincronizado",
    tipo_filtro: "Filtro",
    no_movimientos: "No hay movimientos registrados",
    presione_mas: "Presiona el botón '+' o 'Demo' para registrar.",
    optimizar_sueno: "Prako de FinDream AI",
    consejo_gasto: "Tu mayor gasto registrado es en",
    consejo_ahorro: "Consejo de Ahorro",
    consejo_ahorro_desc: "Al optimizar un 15% en {cat}, sumarás {amount} adicionales al mes directamente a tu meta del sueño, ¡adelantando tu fecha de cumplimiento!",
    nuevo_movimiento: "Nuevo Movimiento",
    dictar_por_voz: "Dictar por Voz (IA)",
    registro_manual: "Registro Manual",
    tipo_flujo: "Tipo de Flujo",
    gasto: "Gasto",
    ingreso: "Ingreso",
    monto_valor: "Monto",
    categoria_gasto: "Categoría de Gasto",
    forma_pago: "Forma de Pago",
    descripcion_opc: "Descripción (Opcional)",
    guardar_movimiento: "Guardar Movimiento",
    datos_basicos: "Datos Básicos",
    nombre_completo: "Nombre Completo",
    correo_electronico: "Correo Electrónico",
    celular_telefono: "Celular / Teléfono",
    bancos_colombianos: "Mis Bancos y Portafolios",
    vincular_pagos: "Vincúlalos para que aparezcan en tu selector de pagos",
    registrar_producto: "Registrar Nuevo Producto",
    banco_co: "Entidad Financiera",
    tipo_producto: "Tipo de Producto",
    alias_opcional: "Alias (Opcional)",
    guardar_producto: "Guardar Producto",
    productos_vigentes: "Productos Actuales",
    finalizar: "Listo, Finalizar",
    habla_libremente: "Habla libremente diciendo 'Registrar gasto de 20 mil en comida'",
    consejo_rapido: "Consejo rápido: di de forma clara el tipo, valor y categoría",
    comenzar_hablar: "Comenzar a hablar",
    detener: "Detener",
    procesando_voz: "Procesando voz con Gemini API...",
    entrar: "Entrar",
    volver: "Volver",
    suscribirse: "Suscribirse",
    iniciar_sesion: "Iniciar Sesión",
    ya_eres_usuario: "¿Ya eres usuario?",
    iniciar_sesion_google: "Iniciar sesión con Google",
    iniciar_sesion_apple: "Iniciar sesión con Apple",
    iniciar_sesion_correo: "Iniciar sesión con Correo",
    demostracion_datos: "Demo (Datos de prueba)",
    // Chatbot Translations:
    ai_insights_title: "Prako de FinDream AI",
    ai_insights_subtitle: "Asesor financiero inteligente potenciado por Gemini",
    chat_placeholder: "Pregúntame sobre tus metas, gastos o consejos...",
    chat_send: "Enviar",
    chat_suggested: "Preguntas Sugeridas:",
    chat_suggest_1: "Analiza mi situación financiera actual",
    chat_suggest_2: "¿Cómo puedo lograr mi sueño más rápido?",
    chat_suggest_3: "Consejos para ahorrar o reducir deudas",
    chat_suggest_4: "Reconocer bancos de mi país para ahorrar",
    chat_initial_greeting: "¡Hola! Soy **Prako**, tu asesor financiero personal de FinDream. Puedo analizar tus deudas, ingresos y tu meta de ahorro. ¿En qué puedo ayudarte hoy?",
    tab_productos: "Producto",
    tab_portafolio: "Portafolio",
    productos_actuales: "Mis Productos",
    recomendaciones_ai: "Recomendaciones AI",
    sincronizado_ai: "Sincronizado automáticamente con tus gastos",
    sin_productos: "Aún no tienes elementos de portafolio registrados en esta pestaña.",
    costo_mensual: "Costo Mensual",
    beneficios: "Beneficios",
  },
  EN: {
    tab_resumen: "Summary",
    tab_sueno: "Dream",
    tab_insights: "Insights",
    ingresar_movimiento: "Enter Finances",
    mi_cuenta: "My Account",
    ingresos: "Assets / Income",
    egresos: "Liabilities / Expenses",
    saldo_neto: "Net Balance",
    deuda: "Liabilities / Debts",
    sincronizado: "Synced",
    tipo_filtro: "Filter",
    no_movimientos: "No recorded transactions",
    presione_mas: "Press the '+' or 'Demo' button to start.",
    optimizar_sueno: "Prako from FinDream AI",
    consejo_gasto: "Your largest recorded expense is in",
    consejo_ahorro: "Save Advice",
    consejo_ahorro_desc: "By optimizing 15% in {cat}, you will add an additional {amount} per month directly to your dream goal, advancing your target date!",
    nuevo_movimiento: "New Transaction",
    dictar_por_voz: "Voice Dictation (AI)",
    registro_manual: "Manual Entry",
    tipo_flujo: "Flow Type",
    gasto: "Expense",
    ingreso: "Income",
    monto_valor: "Amount",
    categoria_gasto: "Expense Category",
    forma_pago: "Payment Method",
    descripcion_opc: "Description (Optional)",
    guardar_movimiento: "Save Transaction",
    datos_basicos: "Basic Info",
    nombre_completo: "Full Name",
    correo_electronico: "Email Address",
    celular_telefono: "Cell / Phone",
    bancos_colombianos: "My Banks & Portfolios",
    vincular_pagos: "Link them to display in your payment selectors",
    registrar_producto: "Register New Product",
    banco_co: "Financial Institution",
    tipo_producto: "Product Type",
    alias_opcional: "Alias (Optional)",
    guardar_producto: "Save Product",
    productos_vigentes: "Active Products",
    finalizar: "Done, Finish",
    habla_libremente: "Speak freely saying 'Record an expense of 20 thousand on food'",
    consejo_rapido: "Quick tip: state clearly the type, value and category",
    comenzar_hablar: "Start Speaking",
    detener: "Stop",
    procesando_voz: "Processing voice with Gemini API...",
    entrar: "Enter",
    volver: "Back",
    suscribirse: "Subscribe",
    iniciar_sesion: "Log In",
    ya_eres_usuario: "Already a user?",
    iniciar_sesion_google: "Log in with Google",
    iniciar_sesion_apple: "Log in with Apple",
    iniciar_sesion_correo: "Log in with Email",
    demostracion_datos: "Demo (Sample Data)",
    // Chatbot Translations:
    ai_insights_title: "Prako from FinDream AI",
    ai_insights_subtitle: "Intelligent financial assistant powered by Gemini",
    chat_placeholder: "Ask me about your goals, expenses or tips...",
    chat_send: "Send",
    chat_suggested: "Suggested Questions:",
    chat_suggest_1: "Analyze my current financial situation",
    chat_suggest_2: "How can I achieve my dream faster?",
    chat_suggest_3: "Tips to save or reduce debts",
    chat_suggest_4: "Recommend savings products for my country",
    chat_initial_greeting: "Hello! I am **Prako**, your personal financial assistant from FinDream. I can analyze your debts, income, and your savings goal. How can I assist you today?",
    tab_productos: "Product",
    tab_portafolio: "Portfolio",
    productos_actuales: "My Products",
    recomendaciones_ai: "AI Recommendations",
    sincronizado_ai: "Automatically synced with your expenses",
    sin_productos: "No registered portfolio items yet in this tab.",
    costo_mensual: "Monthly Cost",
    beneficios: "Benefits",
  }
};


// Helper to synthesise iOS haptic/audio feedback using Web Audio API
const playTone = (type: 'tap' | 'success' | 'delete' | 'voice', isMuted: boolean) => {
  if (isMuted) return;
  try {
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;
    const ctx = new AudioContext();
    
    if (type === 'tap') {
      // Short click sound
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(300, ctx.currentTime + 0.08);
      gain.gain.setValueAtTime(0.05, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.08);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.08);
    } else if (type === 'success') {
      // High-pitched double ding (success theme)
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc1.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
      osc1.frequency.setValueAtTime(659.25, ctx.currentTime + 0.08); // E5
      osc2.frequency.setValueAtTime(783.99, ctx.currentTime); // G5
      osc2.frequency.setValueAtTime(1046.50, ctx.currentTime + 0.08); // C6
      
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.25);
      
      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);
      osc1.start();
      osc2.start();
      osc1.stop(ctx.currentTime + 0.25);
      osc2.stop(ctx.currentTime + 0.25);
    } else if (type === 'delete') {
      // Swish / Low drop sound
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(300, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(80, ctx.currentTime + 0.15);
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.15);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.15);
    } else if (type === 'voice') {
      // Soft ambient alert
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(660, ctx.currentTime + 0.12);
      gain.gain.setValueAtTime(0.06, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.12);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.12);
    }
  } catch (error) {
    console.error("Audio synthesiser error", error);
  }
};

const CATEGORIAS_PREDEFINIDAS: Omit<Categoria, 'monto'>[] = [
  { nombre: 'Vivienda', icon: 'Home', color: '#8B5A2B' }, // Brown
  { nombre: 'Alimentación', icon: 'Utensils', color: '#F97316' }, // Orange
  { nombre: 'Transporte', icon: 'Car', color: '#EF4444' }, // Red
  { nombre: 'Compras', icon: 'ShoppingBag', color: '#EC4899' }, // Pink
  { nombre: 'Viajes', icon: 'Plane', color: '#3B82F6' }, // Blue
  { nombre: 'Cuidado Personal y Entretenimiento', icon: 'Sparkles', color: '#10B981' }, // Emerald Theme
  { nombre: 'Otros', icon: 'MoreHorizontal', color: '#6B7280' }, // Grey
];

// Colombia Specific Financial Lists
const COLOMBIAN_BANKS = [
  'Bancolombia',
  'Banco de Bogotá',
  'Davivienda',
  'BBVA Colombia',
  'Banco Falabella',
  'Banco Éxito / Tuya',
  'Nequi',
  'Daviplata',
  'Scotiabank Colpatria',
  'Banco de Occidente',
  'Banco Popular',
  'Banco AV Villas',
  'Nu Colombia (Nubank)',
  'Lulo Bank',
  'RappiPay'
];

const COLOMBIAN_PRODUCTS = [
  'Tarjeta de Crédito',
  'Tarjeta de Débito',
  'Cuenta de Ahorros',
  'Cuenta Corriente',
  'Bolsillo / Cajita de Ahorro',
  'Fondo de Inversión Colectiva (FIC)',
  'Fondo de Pensiones Voluntarias (FPV)',
  'CDT',
  'Crédito de Consumo',
  'Crédito de Libranza',
  'Crédito de Vehículo',
  'Crédito Hipotecario',
  'Leasing Habitacional',
  'Cupo Rotativo / Crediágil'
];

const PRODUCT_TAB_DEBTS_ONLY = [
  'Tarjeta de Crédito',
  'Crédito de Consumo',
  'Crédito de Libranza',
  'Crédito de Vehículo',
  'Crédito Hipotecario',
  'Leasing Habitacional',
  'Cupo Rotativo / Crediágil'
];

const COLOMBIAN_FRANCHISES = [
  'Ninguna / No Aplica',
  'Visa',
  'Mastercard',
  'American Express',
  'Diners Club'
];

const translateProduct = (p: string, lang: 'ES' | 'EN'): string => {
  if (lang === 'ES') return p;
  const mapping: Record<string, string> = {
    'Tarjeta de Crédito': 'Credit Card',
    'Tarjeta de Débito': 'Debit Card',
    'Cuenta de Ahorros': 'Savings Account',
    'Cuenta Corriente': 'Checking Account',
    'Bolsillo / Cajita de Ahorro': 'Savings Pocket / Box',
    'Fondo de Inversión Colectiva (FIC)': 'Collective Investment Fund (FIC)',
    'Fondo de Pensiones Voluntarias (FPV)': 'Voluntary Pension Fund (FPV)',
    'CDT': 'Certificate of Deposit (CDT)',
    'Crédito de Consumo': 'Consumer Loan',
    'Crédito de Libranza': 'Payroll Loan',
    'Crédito de Vehículo': 'Car Loan',
    'Crédito Hipotecario': 'Mortgage Loan',
    'Leasing Habitacional': 'Housing Leasing',
    'Cupo Rotativo / Crediágil': 'Revolving Credit / Credit Line'
  };
  return mapping[p] || p;
};

const translateFranchise = (f: string, lang: 'ES' | 'EN'): string => {
  if (f === 'Ninguna / No Aplica') {
    return lang === 'ES' ? 'Ninguna / No Aplica' : 'None / Not Applicable';
  }
  return f;
};

const translateCategory = (cat: string, lang: 'ES' | 'EN'): string => {
  if (lang === 'ES') return cat;
  const mapping: Record<string, string> = {
    'Vivienda': 'Housing',
    'Alimentación': 'Food / Groceries',
    'Transporte': 'Transportation',
    'Compras': 'Shopping',
    'Viajes': 'Travel',
    'Cuidado Personal y Entretenimiento': 'Personal Care & Entertainment',
    'Mascotas': 'Pets',
    'Moda y Estilo': 'Fashion & Style',
    'Otros': 'Others'
  };
  return mapping[cat] || cat;
};

interface RecommendedProduct {
  id: string;
  banco: string;
  producto: string;
  costoMensual: string;
  beneficios: string[];
  razon: string;
}

const matchesFilter = (prod: ProductoFinanciero, filter: 'all' | 'debit' | 'credit' | 'credits'): boolean => {
  if (filter === 'all') return true;
  const lowerTipo = (prod.tipo || '').toLowerCase();
  
  if (filter === 'debit') {
    return lowerTipo.includes('débito') || lowerTipo.includes('debito') || lowerTipo.includes('cuenta') || lowerTipo.includes('ahorro') || lowerTipo.includes('corriente') || lowerTipo.includes('fondo') || lowerTipo.includes('bolsillo') || lowerTipo.includes('cajita') || lowerTipo.includes('fic') || lowerTipo.includes('fpv');
  }
  if (filter === 'credit') {
    return lowerTipo.includes('tarjeta de crédito') || lowerTipo.includes('tarjeta de credito') || (lowerTipo.includes('tarjeta') && lowerTipo.includes('crédito')) || (lowerTipo.includes('tarjeta') && lowerTipo.includes('credito'));
  }
  if (filter === 'credits') {
    return (lowerTipo.includes('crédito') || lowerTipo.includes('credito') || lowerTipo.includes('cdt') || lowerTipo.includes('préstamo') || lowerTipo.includes('prestamo') || lowerTipo.includes('hipotecario') || lowerTipo.includes('consumo') || lowerTipo.includes('libranza') || lowerTipo.includes('vehículo') || lowerTipo.includes('vehiculo') || lowerTipo.includes('leasing')) && !lowerTipo.includes('tarjeta');
  }
  return false;
};

const getRecommendedProducts = (
  transacciones: Transaccion[],
  currentProducts: ProductoFinanciero[],
  country: string,
  lang: string
): RecommendedProduct[] => {
  const isEn = lang === 'EN';
  const recs: RecommendedProduct[] = [];

  // Exclude already added banks if possible to suggest new ones
  const hasNequi = currentProducts.some(p => p.banco.toLowerCase().includes('nequi'));
  const hasBancolombia = currentProducts.some(p => p.banco.toLowerCase().includes('bancolombia'));
  const hasDavivienda = currentProducts.some(p => p.banco.toLowerCase().includes('davivienda'));

  // Calculate expenses by category
  const categoryExpenses: Record<string, number> = {};
  transacciones
    .filter(t => t.tipo === 'Gasto')
    .forEach(t => {
      const cat = t.categoria || 'Otros';
      categoryExpenses[cat] = (categoryExpenses[cat] || 0) + t.monto;
    });

  // Find highest category
  let topCategory = '';
  let maxExpense = 0;
  Object.entries(categoryExpenses).forEach(([cat, val]) => {
    if (val > maxExpense) {
      maxExpense = val;
      topCategory = cat;
    }
  });

  // Recommendation 1 based on spending behavior or default
  if (topCategory === 'Alimentación' || topCategory === 'Food') {
    recs.push({
      id: 'rec-1',
      banco: 'Bancolombia',
      producto: isEn ? 'MasterCard Black Dining Credit Card' : 'Tarjeta de Crédito MasterCard Black Gastronómica',
      costoMensual: '$26.000 COP',
      beneficios: isEn 
        ? ['10% cashback on restaurants and delivery', 'No interest for first 3 months', 'Exclusive VIP passes to dining events']
        : ['15% de Cashback en restaurantes y domicilios todos los viernes', 'Acumula doble puntaje para viajes', 'Membresía gratis en apps de envíos favoritos'],
      razon: isEn 
        ? 'Since your top expense is Food, this card maximizes dining cashback.'
        : 'Como tu mayor gasto registrado es Alimentación, esta tarjeta te devolverá más dinero en tus restaurantes.'
    });
  } else if (topCategory === 'Transporte' || topCategory === 'Transport') {
    recs.push({
      id: 'rec-1',
      banco: 'Davivienda',
      producto: isEn ? 'Visa Transmi/Didi Transit Card' : 'Tarjeta Débito Davivienda Transmi-Glow',
      costoMensual: '$0 COP',
      beneficios: isEn
        ? ['Free monthly transit credits', '3% discount on fuel or taxi apps', 'No monthly fee with 2 dynamic payments']
        : ['Pasajes gratis mensuales con TransMilenio', 'Descuento de 4% en gasolineras seleccionadas', 'Sin cuota de manejo si es tu cuenta principal'],
      razon: isEn
        ? 'Based on your Transport expenses, this card offers free transit credits.'
        : 'Dado tu frecuente uso en Transporte, esta alianza optimiza tu movilidad diaria.'
    });
  } else if (topCategory === 'Compras' || topCategory === 'Shopping') {
    recs.push({
      id: 'rec-1',
      banco: 'Scotiabank Colpatria',
      producto: isEn ? 'Visa ShopPro Credit Premium' : 'Tarjeta Scotiabank One Light Shopping',
      costoMensual: '$15.500 COP',
      beneficios: isEn
        ? ['5% off in top department stores', '0% interest installment plans', 'Purchase protection insurance']
        : ['5% de descuento en almacenes de cadena y retail', 'Financiamiento a 0% de interés a 3 cuotas', 'Protección contra robo o daño de compras'],
      razon: isEn
        ? 'Recommended for your high shopping activity, helping you defer costs at 0%.'
        : 'Recomendado por tu alta actividad de Compras, ayudando a diferir sin pagar intereses.'
    });
  } else if (topCategory === 'Viajes' || topCategory === 'Trips') {
    recs.push({
      id: 'rec-1',
      banco: 'BBVA Colombia',
      producto: isEn ? 'Visa Infinite Latam Pass' : 'Tarjeta BBVA Latam Pass Premium',
      costoMensual: '$29.000 COP',
      beneficios: isEn
        ? ['Uncapped miles per USD spent', 'Free access to El Dorado VIP lounge', 'Premium travel cancellation backup']
        : ['Millas ilimitadas por cada dólar en compras', 'Acceso preferencial gratis a salas VIP El Dorado', 'Seguro de viaje con cobertura médica mundial'],
      razon: isEn
        ? 'Recommended for your Travel records, giving you faster access to flights.'
        : 'Recomendada por tus registros de Viajes, permitiendo redimir vuelos gratis rápido.'
    });
  } else if (topCategory === 'Cuidado Personal y Entretenimiento') {
    recs.push({
      id: 'rec-1',
      banco: 'Banco de Bogotá',
      producto: isEn ? 'Visa Play and Wellness Card' : 'Tarjeta Joven Visa Play & Bienestar',
      costoMensual: '$9.900 COP',
      beneficios: isEn
        ? ['2x1 cinema tickets always', '15% discount on spas and wellness centers', 'No handling fee if you are under 28']
        : ['2x1 en salas de cine e invitaciones a conciertos', '15% descuento en gimnasios y spas seleccionados', 'Cero cuota de manejo para menores de 28 años'],
      razon: isEn
        ? 'Since you enjoy personal care & entertainment, this card saves on fun & health.'
        : 'Por tus hábitos de autocuidado y entretenimiento, esta tarjeta reduce tus costos de recreación.'
    });
  } else {
    // Default fallback based on highest expense or general recommendation
    recs.push({
      id: 'rec-1',
      banco: 'Bancolombia',
      producto: isEn ? 'Visa Free Handling Fee Card' : 'Tarjeta de Crédito Libre Bancolombia',
      costoMensual: '$0 COP',
      beneficios: isEn
        ? ['Forever $0 monthly handling fee', 'Ideal for first-time credit building', '1.5% cashback on subscription services']
        : ['Cuota de manejo de por vida de $0 COP', 'Ideal para construir historial crediticio sin deudas', 'Descuento exclusivo en suscripciones de música/streaming'],
      razon: isEn
        ? 'A general-purpose card with zero maintenance cost to build healthy savings.'
        : 'Una tarjeta básica con costo cero de mantenimiento ideal para tu presupuesto actual.'
    });
  }

  // Recommendation 2: Fintech / Digital wallets if not added yet
  if (!hasNequi) {
    recs.push({
      id: 'rec-2',
      banco: 'Nu Colombia (Nubank)',
      producto: isEn ? 'Nu Credit Card' : 'Tarjeta de Crédito Nu',
      costoMensual: '$0 COP',
      beneficios: isEn
        ? ['Zero handling fees for life', 'No international transaction fees', 'Virtual card for safe online shopping']
        : ['Sin cuota de manejo de por vida', 'Sin cobros adicionales por compras internacionales', 'Tarjeta virtual para compras online seguras'],
      razon: isEn
        ? 'Perfect for standardising your credit safely without any hidden costs.'
        : 'Ideal para consolidar compras sin pagar costos fijos mensuales ni cuotas escondidas.'
    });
  } else if (!hasDavivienda && !currentProducts.some(p => p.banco === 'Daviplata')) {
    recs.push({
      id: 'rec-2',
      banco: 'RappiPay',
      producto: isEn ? 'RappiCard Visa' : 'RappiCard Visa',
      costoMensual: '$0 COP',
      beneficios: isEn
        ? ['1% Cashback on all purchases', 'No handling fees', 'Exclusive discounts in Rappi app']
        : ['1% de Cashback real en todas tus compras', 'Cero cuotas de manejo de por vida', 'Descuentos exclusivos y beneficios en Rappi'],
      razon: isEn
        ? 'Great option for earning money back on your daily expenses.'
        : 'Excelente opción si usas delivery y quieres recibir dinero real por cada compra.'
    });
  } else {
    recs.push({
      id: 'rec-2',
      banco: 'Lulo Bank',
      producto: isEn ? 'Lulo Credit' : 'Crédito de Libre Inversión Lulo',
      costoMensual: '$0 COP',
      beneficios: isEn
        ? ['Fixed personalized rate', 'Approval in minutes directly in the app', 'No physical branch visits required']
        : ['Tasa fija personalizada según tu perfil', 'Aprobación en minutos 100% desde la app', 'Sin papeleos ni visitas a sucursales'],
      razon: isEn
        ? 'Highly recommended for consolidating other debts quickly and securely.'
        : 'Recomendada para unificar deudas o capitalizar un consumo rápido a tasas claras.'
    });
  }

  return recs;
};

// Helper to get matching Lucide icon dynamically
const renderCategoriaIcon = (iconName: string, color: string, className = "w-5 h-5") => {
  switch (iconName) {
    case 'Home': return <Home className={className} style={{ color }} />;
    case 'Utensils': return <Utensils className={className} style={{ color }} />;
    case 'Car': return <Car className={className} style={{ color }} />;
    case 'ShoppingBag': return <ShoppingBag className={className} style={{ color }} />;
    case 'Plane': return <Plane className={className} style={{ color }} />;
    case 'Sparkles': return <Sparkles className={className} style={{ color }} />;
    case 'Heart': return <Heart className={className} style={{ color }} />;
    case 'Scissors': return <Scissors className={className} style={{ color }} />;
    default: return <MoreHorizontal className={className} style={{ color }} />;
  }
};

export default function App() {
  // Customizable categories state loaded from localStorage with premium defaults
  const [categorias, setCategorias] = useState<Omit<Categoria, 'monto'>[]>([
    { nombre: 'Vivienda', icon: 'Home', color: '#8B5A2B' },
    { nombre: 'Alimentación', icon: 'Utensils', color: '#F97316' },
    { nombre: 'Transporte', icon: 'Car', color: '#EF4444' },
    { nombre: 'Compras', icon: 'ShoppingBag', color: '#EC4899' },
    { nombre: 'Viajes', icon: 'Plane', color: '#3B82F6' },
    { nombre: 'Cuidado Personal y Entretenimiento', icon: 'Sparkles', color: '#10B981' },
    { nombre: 'Mascotas', icon: 'Heart', color: '#F43F5E' },
    { nombre: 'Moda y Estilo', icon: 'Scissors', color: '#9333EA' },
    { nombre: 'Otros', icon: 'MoreHorizontal', color: '#6B7280' },
  ]);

  // Explicitly save any changes to categories state
  const saveCategorias = (novas: Omit<Categoria, 'monto'>[]) => {
    setCategorias(novas);
    try {
      pushToFirestore(undefined, undefined, undefined, novas, undefined);
    } catch (e) {}
  };

  // Manage categories panel helper state
  const [showManageCategories, setShowManageCategories] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [newCatColor, setNewCatColor] = useState('#008B81');
  const [newCatIcon, setNewCatIcon] = useState('Home');

  // Suggest sensible icon and color automatically based on typed category name
  useEffect(() => {
    const term = newCatName.toLowerCase().trim();
    if (!term) return;

    const petKeywords = ['mascota', 'mascotas', 'perro', 'gato', 'animal', 'pet', 'pets', 'dog', 'cat', 'veterinari', 'veterinario', 'veterinaria', 'peludo', 'fiel'];
    const foodKeywords = ['comida', 'restaurante', 'alimento', 'cena', 'almuerzo', 'desayuno', 'bocadillo', 'cafe', 'comidas', 'food', 'market', 'supermercado', 'fruta', 'verdura', 'domicilio', 'domicilios'];
    const travelKeywords = ['viaje', 'vuelo', 'avion', 'hotel', 'aeropuerto', 'pasaje', 'viajes', 'turismo', 'travel', 'trip', 'escapada'];
    const carKeywords = ['carro', 'transporte', 'auto', 'moto', 'gasolina', 'uber', 'taxi', 'peaje', 'vehiculo', 'gas', 'car', 'mantenimiento', 'taller', 'repuestos'];
    const shopKeywords = ['compras', 'compra', 'mercado', 'mall', 'shopp', 'shopping', 'regalo', 'regalos', 'tienda', 'retail', 'regalar'];
    const homeKeywords = ['casa', 'arriendo', 'hogar', 'vivienda', 'muebles', 'alquiler', 'luz', 'agua', 'gas', 'servicio', 'servicios', 'home', 'reparaciones'];
    const fashionKeywords = ['moda', 'ropa', 'fashion', 'peluqueria', 'tijeras', 'estilo', 'cortar', 'barbero', 'estilista', 'scissors', 'vestido', 'zapatos', 'corte', 'barba'];
    const sparklesKeywords = ['belleza', 'magia', 'limpieza', 'tecnologia', 'gadget', 'computador', 'diversion', 'ocio', 'entretenimiento', 'suscripcion', 'netflix', 'spotify', 'cine', 'luxury', 'brillo'];

    if (petKeywords.some(kw => term.includes(kw))) {
      setNewCatIcon('Heart');
      setNewCatColor('#F43F5E'); // Vibrant Rose-Pink
    } else if (foodKeywords.some(kw => term.includes(kw))) {
      setNewCatIcon('Utensils');
      setNewCatColor('#F97316'); // Orange
    } else if (travelKeywords.some(kw => term.includes(kw))) {
      setNewCatIcon('Plane');
      setNewCatColor('#3B82F6'); // Blue
    } else if (carKeywords.some(kw => term.includes(kw))) {
      setNewCatIcon('Car');
      setNewCatColor('#EF4444'); // Red
    } else if (shopKeywords.some(kw => term.includes(kw))) {
      setNewCatIcon('ShoppingBag');
      setNewCatColor('#EC4899'); // Pink
    } else if (homeKeywords.some(kw => term.includes(kw))) {
      setNewCatIcon('Home');
      setNewCatColor('#8B5A2B'); // Brown
    } else if (fashionKeywords.some(kw => term.includes(kw))) {
      setNewCatIcon('Scissors');
      setNewCatColor('#9333EA'); // Purple
    } else if (sparklesKeywords.some(kw => term.includes(kw))) {
      setNewCatIcon('Sparkles');
      setNewCatColor('#10B981'); // Emerald
    }
  }, [newCatName]);

  // Simulator state VS Full Screen State
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [simulatedTime, setSimulatedTime] = useState('09:41');
  const [simulatedBattery] = useState(88);
  const [isMuted, setIsMuted] = useState(false);
  const [showSplash, setShowSplash] = useState(() => {
    try {
      const stored = localStorage.getItem('finanza_user_profile_v2');
      return !stored;
    } catch (e) {
      return true;
    }
  });
  
  // Country & Language config state
  const [selectedCountry, setSelectedCountry] = useState<'CO' | 'US' | 'ES' | 'MX'>('CO');
  const [selectedLanguage, setSelectedLanguage] = useState<'ES' | 'EN'>('ES');

  // Translation Function (Dynamic Key Mapping)
  const t = (key: keyof typeof TRANSLATIONS.ES, replaces?: Record<string, string>): string => {
    const lang = selectedLanguage === 'EN' ? 'EN' : 'ES';
    let text = TRANSLATIONS[lang][key] || TRANSLATIONS.ES[key] || '';
    if (replaces) {
      Object.entries(replaces).forEach(([k, v]) => {
        text = text.replace(`{${k}}`, v);
      });
    }
    return text;
  };

  // Currency specific calculations
  const formatCurrency = (val: number): string => {
    const currencySettings: Record<string, { symbol: string; locale: string }> = {
      CO: { symbol: '$', locale: 'es-CO' },
      US: { symbol: '$', locale: 'en-US' },
      ES: { symbol: '€', locale: 'es-ES' },
      MX: { symbol: '$', locale: 'es-MX' },
    };
    const { symbol, locale } = currencySettings[selectedCountry] || { symbol: '$', locale: 'es-CO' };
    const formatted = val.toLocaleString(locale, {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    });
    return `${symbol}${formatted}`;
  };

  // Navigation tabs state
  const [activeTab, setActiveTab] = useState<'finance' | 'cloud' | 'productos' | 'portafolios' | 'insights'>('finance');
  
  // Portafolio state
  const [nuevoPortafolio, setNuevoPortafolio] = useState({ nombre: '', valor: '', plataforma: '' });
  const [activeProductSubTab, setActiveProductSubTab] = useState<'actuales' | 'recomendaciones'>('actuales');
  const [activeInsightSubTab, setActiveInsightSubTab] = useState<'asesor' | 'insights'>('asesor');
  const [portfolioFilter, setPortfolioFilter] = useState<'all' | 'debit' | 'credit' | 'credits'>('all');
  
  // States for Hidden Product Forms (Toggle with + button)
  const [showAddProductTab, setShowAddProductTab] = useState(false);
  const [showAddProductSettings, setShowAddProductSettings] = useState(false);

  // States for Editing Transaction
  const [editingTransaction, setEditingTransaction] = useState<Transaccion | null>(null);
  const [editingPortafolio, setEditingPortafolio] = useState<any | null>(null);
  const [isSearchingCustomProducts, setIsSearchingCustomProducts] = useState(false);
  const [customProductError, setCustomProductError] = useState<string | null>(null);
  const [customProductRecommendations, setCustomProductRecommendations] = useState<any[]>([]);
  const [customProductQuery, setCustomProductQuery] = useState('');
  const [recommendationMode, setRecommendationMode] = useState<'ai' | 'explore' | 'manual'>('ai');

  const [editPortafolioNombre, setEditPortafolioNombre] = useState('');
  const [editPortafolioValor, setEditPortafolioValor] = useState('');
  const [editPortafolioPlataforma, setEditPortafolioPlataforma] = useState('');

  // Security Locking / Confirm Identity on start
  const [isAppLocked, setIsAppLocked] = useState(() => {
    try {
      const hasProfile = localStorage.getItem('finanza_user_profile_v2');
      if (hasProfile) {
        const parsed = JSON.parse(hasProfile);
        return !!parsed.contraseña;
      }
      return false;
    } catch (e) {
      return false;
    }
  });
  const [lockPasswordInput, setLockPasswordInput] = useState('');
  const [lockIsScanning, setLockIsScanning] = useState(false);
  const [lockStatus, setLockStatus] = useState({ type: '', text: '' });

  // Biometrics enrollment & activation states
  const [isBiometricRegistered, setIsBiometricRegistered] = useState(() => {
    try {
      return localStorage.getItem('findream_biometric_registered') === 'true';
    } catch (e) {
      return false;
    }
  });
  const [isEnrollingBiometrics, setIsEnrollingBiometrics] = useState(false);
  const [biometricEnrollMsg, setBiometricEnrollMsg] = useState({ type: '', text: '' });

  // User profile and Colombia Financial products registry
  const [isCuentaOpen, setIsCuentaOpen] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    try {
      const savedTemp = localStorage.getItem('finanza_user_profile_v6_temp');
      if (savedTemp) return JSON.parse(savedTemp);
      
      const savedReal = localStorage.getItem('finanza_user_profile_v2');
      if (savedReal) return JSON.parse(savedReal);
    } catch {}

    return {
      nombre: 'Invitado',
      correo: '',
      celular: '',
      productos: [],
      portafolios: []
    };
  });

  // Multiple Dreams (Sueño) persistent configuration
  const [suenos, setSuenos] = useState<Sueno[]>([]);
  const [activeSuenoId, setActiveSuenoId] = useState<string>('');

  // Load States on mount or when splash completes
  useEffect(() => {
    const savedTemp = localStorage.getItem('finanza_user_profile_v6_temp');
    if (savedTemp) {
      try {
        const parsed = JSON.parse(savedTemp);
        setUserProfile(parsed);
        localStorage.setItem('finanza_user_profile_v2', savedTemp);
        localStorage.removeItem('finanza_user_profile_v6_temp');
      } catch (e) {
        console.error(e);
      }
    } else {
      const savedReal = localStorage.getItem('finanza_user_profile_v2');
      if (savedReal) {
        try {
          setUserProfile(JSON.parse(savedReal));
        } catch (e) {
          console.error(e);
        }
      }
    }
  }, [showSplash]);

  // Payment Methods persistent configuration
  const [paymentMethods, setPaymentMethods] = useState<string[]>([
    'Efectivo',
    'Tarjeta de Débito',
    'Tarjeta de Crédito',
    'Transferencia Bancaria'
  ]);

  useEffect(() => {
    getRedirectResult(auth)
      .then((result) => {
        if (result?.user) {
          console.log('Login redirect exitoso:', result.user.email);
          setIsAppLocked(false);
          setShowSplash(false);

          const pendingScopes = sessionStorage.getItem('pending_sheets_scopes');
          if (pendingScopes) {
            const credential = GoogleAuthProvider.credentialFromResult(result);
            if (credential?.accessToken) {
              const scopes = JSON.parse(pendingScopes);
              setCachedAccessToken(credential.accessToken, scopes);
              sessionStorage.removeItem('pending_sheets_scopes');
              
              // Trigger sheets import
              setTimeout(() => {
                if (importFromSheetsRef.current) {
                  importFromSheetsRef.current();
                }
              }, 300);
            }
          }
        }
      })
      .catch((error) => {
        console.error('Error de redirect:', error);
        alert('Error al completar el inicio de sesión: ' + error.message);
      });
  }, []);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      if (user && !user.isAnonymous) {
        console.log('Auth state changed - usuario autenticado:', user.email);
        setIsAppLocked(false);
      }
    });
    return () => unsub();
  }, []);

  const saveUserProfileData = (updated: UserProfile) => {
    setUserProfile(updated);
    localStorage.setItem('finanza_user_profile_v2', JSON.stringify(updated));
    pushToFirestore(updated, undefined, undefined, undefined, undefined);
  };

  // Migration: Limpiar datos obsoletos de localStorage (Solo una vez por sesión - Point 2)
  useEffect(() => {
    try {
      const isMigrated = sessionStorage.getItem('finanza_v2_migrated');
      if (!isMigrated) {
        localStorage.removeItem('finanza_user_profile_v6_temp');
        localStorage.removeItem('finanza_user_profile_v1');
        localStorage.removeItem('finanza_last_local_update_old');
        sessionStorage.setItem('finanza_v2_migrated', 'true');
      }
    } catch (e) {}
  }, []);

  // Foolproof stable date parser to prevent any UTC/timezone shifting across all regions.
  // We extract YYYY-MM-DD directly and construct a strictly local Date object at 12:00 PM noon.
  const formatSafeDateString = (isoString: string) => {
    if (!isoString) return new Date();
    const match = isoString.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (match) {
      return new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]), 12, 0, 0);
    }
    // Fallback if string is completely bizarre
    let dateObj = new Date(isoString);
    if (!isoString.includes('T')) {
      dateObj = new Date(isoString + "T12:00:00");
    }
    return dateObj;
  };

  // Create local YYYY-MM-DD string to feed into <input type="date">
  const formatLocalYYYYMMDD = (d: Date) => {
    const pad = (n: number) => n.toString().padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  };

  const startEditingPortafolio = (p: any) => {
    setEditingPortafolio(p);
    setEditPortafolioNombre(p.nombre);
    setEditPortafolioValor(String(p.valor));
    setEditPortafolioPlataforma(p.plataforma);
  };

  const handleCustomProductSearch = async (queryText: string) => {
    if (!queryText.trim()) return;
    setIsSearchingCustomProducts(true);
    setCustomProductError(null);
    try {
      const response = await fetch("/api/gemini/recommend-custom-products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: queryText,
          country: selectedCountry === 'CO' ? 'Colombia' : selectedCountry === 'US' ? 'United States' : selectedCountry === 'ES' ? 'Spain' : 'Mexico',
          language: selectedLanguage,
        })
      });

      if (!response.ok) {
        throw new Error(selectedLanguage === 'ES' ? "No se pudo obtener las recomendaciones de la IA." : "Failed to obtain AI recommendations.");
      }

      const data = await response.json();
      if (data && data.products) {
        setCustomProductRecommendations(data.products);
      } else {
        throw new Error(selectedLanguage === 'ES' ? "Respuesta inválida de la IA." : "Invalid response from AI.");
      }
    } catch (err: any) {
      console.error(err);
      setCustomProductError(err.message || "Ocurrió un error.");
    } finally {
      setIsSearchingCustomProducts(false);
    }
  };



  const handleLinkRecommendedProduct = (rec: RecommendedProduct) => {
    let tipo: any = 'Tarjeta de Crédito';
    const lowerProd = rec.producto.toLowerCase();
    if (lowerProd.includes('cuenta') || lowerProd.includes('ahorro') || lowerProd.includes('débito') || lowerProd.includes('debito')) {
      tipo = 'Cuenta de Ahorros';
    } else if (lowerProd.includes('cdt')) {
      tipo = 'CDT';
    } else if (lowerProd.includes('inversión') || lowerProd.includes('inversion')) {
      tipo = 'Inversión Digital';
    } else if (lowerProd.includes('crédito') || lowerProd.includes('credito') || lowerProd.includes('prestamo') || lowerProd.includes('préstamo')) {
      tipo = 'Crédito de Consumo';
    }

    const newProd: ProductoFinanciero = {
      id: `prod-rec-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      banco: rec.banco,
      tipo: tipo,
      alias: rec.producto,
      montoTotal: undefined,
      montoUtilizado: undefined
    };

    const updatedProds = [...(userProfile.productos || []), newProd];
    saveUserProfileData({ ...userProfile, productos: updatedProds });
    playTone('success', isMuted);
    triggerDynamicIsland(
      selectedLanguage === 'ES' ? "Portafolio Agregado" : "Portfolio Added",
      `${rec.banco} • ${rec.producto}`,
      true
    );
  };

  const getMergedPaymentMethods = (): string[] => {
    const defaults = ['Efectivo', 'Tarjeta de Débito', 'Tarjeta de Crédito', 'PSE / Débito', 'Transferencia Bancaria'];
    if (userProfile.productos && userProfile.productos.length > 0) {
      const bankProducts = userProfile.productos.map(p => {
        const aliasStr = p.alias ? ` (${p.alias})` : '';
        return `${p.banco} - ${p.tipo}${aliasStr}`;
      });
      return Array.from(new Set([...defaults, ...bankProducts]));
    }
    return defaults;
  };

  const getProductUtilizado = (prod: ProductoFinanciero): number => {
    const matchingOptionName = `${prod.banco} - ${prod.tipo}${prod.alias ? ` (${prod.alias})` : ''}`;
    const extraUsed = transacciones.reduce((total, t) => {
      if (t.formaPago === matchingOptionName) {
        if (t.tipo === 'Gasto') {
          return total + t.monto;
        } else if (t.tipo === 'Ingreso') {
          return total - t.monto;
        }
      }
      return total;
    }, 0);
    return Math.max(0, (prod.montoUtilizado || 0) + extraUsed);
  };



  // Initialize chat messages reactively on Language, Dream, or Country changes
  useEffect(() => {
    const actDream = suenos.find(s => s.id === activeSuenoId);
    const dreamName = actDream ? actDream.nombre : (selectedLanguage === 'ES' ? 'tu sueño' : 'your dream');
    const dreamMeta = actDream ? formatCurrency(actDream.meta) : (selectedLanguage === 'ES' ? 'tu meta' : 'your goal');
    
    const rawGreeting = t('chat_initial_greeting');
    const greeting = rawGreeting
      .replace('{dream}', dreamName)
      .replace('{meta}', dreamMeta);

    
  }, [selectedLanguage, activeSuenoId, suenos, selectedCountry]);

  // Translate Category name dynamically for display
  const translateCategory = (catName: string): string => {
    if (selectedLanguage === 'EN') {
      switch (catName) {
        case 'Vivienda': return 'Housing';
        case 'Alimentación': return 'Food';
        case 'Transporte': return 'Transport';
        case 'Compras': return 'Shopping';
        case 'Viajes': return 'Trips';
        case 'Cuidado Personal y Entretenimiento': return 'Personal Care & Entertainment';
        case 'Mascotas': return 'Pets';
        case 'Moda y Estilo': return 'Fashion & Style';
        case 'Otros': return 'Others';
        default: return catName;
      }
    }
    return catName;
  };

  // Securely translate bold markings & bullet lists from raw Markdown output
  const renderMarkdownMsg = (rawText: string) => {
    const parts = rawText.split(/(\*\*[^*]+\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return (
          <strong key={i} className="font-extrabold text-[#006050] bg-teal-50 px-1 py-0.5 rounded-sm border border-teal-100/30">
            {part.slice(2, -2)}
          </strong>
        );
      }
      return <span key={i} className="font-medium">{part}</span>;
    });
  };

  const saveSuenosList = (updated: Sueno[]) => {
    setSuenos(updated);
    pushToFirestore(undefined, undefined, updated, undefined, undefined);
  };

  const handleSelectSueno = (id: string) => {
    setActiveSuenoId(id);
    localStorage.setItem('finanza_suenos_active_id_v2', id);
    playTone('tap', isMuted);
  };

  const handleAddSueno = (nombre: string, meta: number, manualRate: number, usarReal: boolean) => {
    const newSueno: Sueno = {
      id: `sueno-${Date.now()}`,
      nombre,
      meta,
      ahorroManual: manualRate,
      usarReal
    };
    const updated = [...suenos, newSueno];
    saveSuenosList(updated);
    setActiveSuenoId(newSueno.id);
    localStorage.setItem('finanza_suenos_active_id_v2', newSueno.id);
    playTone('success', isMuted);
    triggerDynamicIsland("Nuevo Sueño", `"${nombre}" Añadido`, true);
  };

  const handleUpdateSueno = (updatedSueno: Sueno) => {
    const updated = suenos.map(s => s.id === updatedSueno.id ? updatedSueno : s);
    saveSuenosList(updated);
  };

  const handleDeleteSueno = (id: string) => {
    requestConfirmation(
      "Eliminar Sueño",
      "¿Estás seguro de que deseas eliminar este sueño? La planificación asociada se perderá.",
      () => {
        const filtered = suenos.filter(s => s.id !== id);
        saveSuenosList(filtered);
        if (filtered.length > 0) {
          setActiveSuenoId(filtered[0].id);
          localStorage.setItem('finanza_suenos_active_id_v2', filtered[0].id);
        } else {
          setActiveSuenoId('');
          localStorage.setItem('finanza_suenos_active_id_v2', '');
        }
        playTone('delete', isMuted);
        triggerDynamicIsland("Sueño Eliminado", "Se removió de tu lista.", false);
      }
    );
  };

  const savePaymentMethods = (updated: string[]) => {
    setPaymentMethods(updated);
    pushToFirestore(undefined, undefined, undefined, undefined, updated);
  };

  // Core Financial State
  const [transacciones, setTransacciones] = useState<Transaccion[]>([]);
  const [filtroSeleccionado, setFiltroSeleccionado] = useState<FiltroTiempo>("Mes");
  const [ordenSeleccionado, setOrdenSeleccionado] = useState<'MasReciente' | 'MayorGasto'>('MasReciente');
  // Bottom Sheet State
  const [isAddingOpen, setIsAddingOpen] = useState(false);
  const [startVoiceOnAdd, setStartVoiceOnAdd] = useState(false);
  const [popupInitialChoice, setPopupInitialChoice] = useState<'choice' | 'form' | null>('choice');

  // Custom iOS Confirm Dialog State (completely bypassing blocked iframe popups)
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {}
  });

  const requestConfirmation = (title: string, message: string, onConfirm: () => void) => {
    setConfirmDialog({
      isOpen: true,
      title,
      message,
      onConfirm: () => {
        onConfirm();
        setConfirmDialog(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  // Auth Guide helper states
  const [showAuthGuide, setShowAuthGuide] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [simulatedAuthMode, setSimulatedAuthMode] = useState(() => localStorage.getItem('findream_simulate_auth') === 'true');


  // Dynamic Notch Alert / Dynamic Island Active Notification
  const [notchAlert, setNotchAlert] = useState<{ text: string; subtext: string; isPositive: boolean } | null>(null);

  // Speech Recognition hook states
  const [isUploadingDocument, setIsUploadingDocument] = useState(false);

  const { isSyncing, lastSyncedTime, pushToFirestore, isLocalMode } = useFirestore(
    showSplash,
    userProfile, setUserProfile,
    transacciones, setTransacciones,
    suenos, setSuenos,
    categorias, setCategorias,
    paymentMethods, setPaymentMethods,
    setNotchAlert,
    selectedLanguage
  );

  // Handlers



  const [hoveredSlice, setHoveredSlice] = useState<string | null>(null);
  const [hideBalances, setHideBalances] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('finanza_hide_balances_v2');
      return stored !== null ? stored === 'true' : true;
    } catch (e) {
      return true;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('finanza_hide_balances_v2', String(hideBalances));
    } catch (e) {}
  }, [hideBalances]);

  const handleDocumentUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingDocument(true);
    triggerDynamicIsland("Procesando", selectedLanguage === 'ES' ? "Analizando documento con IA..." : "Analyzing document with AI...", true);

    try {
      let fileBase64 = '';
      let mimeType = file.type;
      let textContent = '';

      if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
        const data = await file.arrayBuffer();
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        textContent = XLSX.utils.sheet_to_csv(worksheet);
        mimeType = 'text/csv';
      } else if (file.type === 'text/csv' || file.name.endsWith('.csv')) {
        textContent = await file.text();
        mimeType = 'text/csv';
      } else {
        const buffer = await file.arrayBuffer();
        const bytes = new Uint8Array(buffer);
        let binary = '';
        for (let i = 0; i < bytes.byteLength; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        fileBase64 = window.btoa(binary);
      }

      const response = await fetch('/api/gemini/extract-document', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileBase64, mimeType, textContent })
      });

      if (!response.ok) throw new Error('Error en el servidor');
      const dataArray = await response.json();
      
      const parsedArray = Array.isArray(dataArray) ? dataArray : [dataArray];
      
      const newTxList = parsedArray.map(data => {
        let cat = 'Otros';
        if (data.categoria) {
          let matchedCat = categorias.find(c => c.nombre.toLowerCase() === data.categoria.toLowerCase());
          if (!matchedCat) {
            matchedCat = categorias.find(c => data.categoria.toLowerCase().includes(c.nombre.toLowerCase()) || 
                                             c.nombre.toLowerCase().includes(data.categoria.toLowerCase()));
          }
          if (matchedCat) cat = matchedCat.nombre;
        }
        
        let forma = getMergedPaymentMethods()[0];
        if (data.banco) {
          const pms = getMergedPaymentMethods();
          let matchedPm = pms.find(pm => pm.toLowerCase().includes(data.banco.toLowerCase()) || data.banco.toLowerCase().includes(pm.toLowerCase()));
          if (matchedPm) forma = matchedPm;
        }
        
        const tx: Transaccion = {
          id: Math.random().toString(36).substring(2, 9),
          tipo: 'Gasto', // Safest logic for uploaded receipts
          monto: Number(data.monto) || 0,
          categoria: cat,
          fecha: data.fecha || formatLocalYYYYMMDD(new Date()),
          descripcion: data.nombre || `Gasto en ${cat}`,
          formaPago: forma
        };
        return tx;
      });
      
      setIsAddingOpen(false);
      
      requestConfirmation(
        selectedLanguage === 'ES' ? "Confirmar importación" : "Confirm import",
        selectedLanguage === 'ES' 
          ? `Se encontraron ${newTxList.length} movimientos por un total de $${newTxList.reduce((acc, t) => acc + t.monto, 0).toLocaleString()}. ¿Deseas agregarlos?` 
          : `Found ${newTxList.length} transactions totaling $${newTxList.reduce((acc, t) => acc + t.monto, 0).toLocaleString()}. Do you want to add them?`,
        () => {
          saveTransacciones([...newTxList, ...transacciones]);
          triggerDynamicIsland("Completado", selectedLanguage === 'ES' ? `Se agregaron ${newTxList.length} movimientos.` : `${newTxList.length} transactions added.`, true);
          playTone('success', isMuted);
        }
      );
    } catch (error) {
      console.error(error);
      triggerDynamicIsland("Error", selectedLanguage === 'ES' ? "No se pudo extraer información del documento" : "Could not extract info from document", false);
    } finally {
      setIsUploadingDocument(false);
      if (e.target) e.target.value = '';
    }
  };

  const importFromSheetsRef = useRef<(() => Promise<void>) | null>(null);

  // --- CONTROLES DE MANTENER PRESIONADO (LONG PRESS) PARA EL BOTÓN + ---
  const longPressTimerRef = useRef<NodeJS.Timeout | null>(null);
  const isHoldingRef = useRef<boolean>(false);

  const startPressLong = (e: React.MouseEvent | React.TouchEvent) => {
    isHoldingRef.current = false;
    
    longPressTimerRef.current = setTimeout(() => {
      isHoldingRef.current = true;
      handleTap(); // Sonido háptico/clic
      
      // Activa dictado por voz directamente, saltando la pantalla de selección
      setPopupInitialChoice('form');
      setIsAddingOpen(true);
      
      // Esperar brevemente que abra la hoja deslizable e iniciar dictado
      setTimeout(() => {
        setStartVoiceOnAdd(true);
      }, 350);
    }, 600); // Tiempo límite para mantener apretado (600ms)
  };

  const endPressLong = (e: React.MouseEvent | React.TouchEvent) => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
    
    // Si NO llegó a considerarse mantener presionado (fue un clic corto)
    if (!isHoldingRef.current) {
      handleTap();
      setPopupInitialChoice('choice');
      setIsAddingOpen(true);
    }
    
    isHoldingRef.current = false;
  };

  const cancelPressLong = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
    isHoldingRef.current = false;
  };



  const saveTransacciones = (novas: Transaccion[]) => {
    setTransacciones(novas);
    pushToFirestore(undefined, novas, undefined, undefined, undefined);
  };

  // Clock Update for iOS top tier
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hh = now.getHours().toString().padStart(2, '0');
      const mm = now.getMinutes().toString().padStart(2, '0');
      setSimulatedTime(`${hh}:${mm}`);
    };
    updateTime();
    const timer = setInterval(updateTime, 10000);
    return () => clearInterval(timer);
  }, []);

  // Dynamic Island Alert timeout
  const triggerDynamicIsland = (text: string, subtext: string, isPositive: boolean) => {
    setNotchAlert({ text, subtext, isPositive });
    let notchTimeout: any; if (notchTimeout) clearTimeout(notchTimeout); notchTimeout = setTimeout(() => {
      setNotchAlert(null);
    }, 4500);
  };

  const {
    isListening: isListeningCustomProduct,
    startListening: startCustomProductSpeechRecognition,
    recognitionError: speechError,
  } = useSpeechRecognition({
    selectedLanguage,
    onTranscriptChange: (text) => setCustomProductQuery(text),
    triggerDynamicIsland,
    playTone,
    isMuted,
  });

  useEffect(() => {
    if (speechError) {
      setCustomProductError(speechError);
    }
  }, [speechError]);

  const { importFromSheets, isImportingSheets } = useGoogleSheets({
    categorias,
    getMergedPaymentMethods,
    selectedLanguage,
    triggerDynamicIsland,
    requestConfirmation,
    setIsAddingOpen,
    isMuted,
    playTone,
    onImportSuccess: (newTxList) => {
      saveTransacciones([...newTxList, ...transacciones]);
    }
  });

  useEffect(() => {
    importFromSheetsRef.current = importFromSheets;
  }, [importFromSheets]);

  // Filter algorithms for current period
  const filterTransactions = (items: Transaccion[]): Transaccion[] => {
    const now = new Date();
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const startOfWeek = startOfDay - (now.getDay() || 7 - 1) * 24 * 3600 * 1000;
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
    const startOfYear = new Date(now.getFullYear(), 0, 1).getTime();

    return items.filter(item => {
      const itemTime = formatSafeDateString(item.fecha).getTime();
      switch (filtroSeleccionado) {
        case 'Día':
          return itemTime >= startOfDay;
        case 'Semana':
          return itemTime >= startOfWeek;
        case 'Mes':
          return itemTime >= startOfMonth;
        case 'Año':
          return itemTime >= startOfYear;
        case 'Histórico':
        default:
          return true;
      }
    });
  };

  const transaccionesFiltradasLista = [...filterTransactions(transacciones)].sort((a, b) => {
    if (ordenSeleccionado === 'MayorGasto') {
      return b.monto - a.monto;
    } else {
      // MasReciente
      return new Date(b.fecha).getTime() - new Date(a.fecha).getTime();
    }
  });

  const transaccionesFiltradas = filterTransactions(transacciones);

  // Recalculates dynamically
  const totalActivos = transaccionesFiltradas
    .filter(t => t.tipo === 'Ingreso')
    .reduce((sum, t) => sum + t.monto, 0);

  const totalPasivos = transaccionesFiltradas
    .filter(t => t.tipo === 'Gasto')
    .reduce((sum, t) => sum + t.monto, 0);

  const realAhorroNeto = totalActivos - totalPasivos;

  // Calculate dynamic categorial sum on-the-fly for pristine precision
  const getCategoriaMonto = (catNombre: string) => {
    return transaccionesFiltradas
      .filter(t => t.tipo === 'Gasto' && t.categoria === catNombre)
      .reduce((sum, t) => sum + t.monto, 0);
  };

  const handleSaveEditedPortafolio = (e: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!editingPortafolio) return;
    
    if (!editPortafolioNombre || !editPortafolioValor || !editPortafolioPlataforma) {
      triggerDynamicIsland("Error", selectedLanguage === 'ES' ? "Todos los campos son obligatorios" : "All fields are required", false);
      return;
    }
    const val = parseFloat(editPortafolioValor.replace(/,/g, ''));
    if (isNaN(val) || val <= 0) {
      triggerDynamicIsland("Error", selectedLanguage === 'ES' ? "Valor inválido" : "Invalid value", false);
      return;
    }
    
    const updatedProfile = {
      ...userProfile,
      portafolios: (userProfile.portafolios || []).map(p => p.id === editingPortafolio.id ? {
        ...p,
        nombre: editPortafolioNombre,
        valor: val,
        plataforma: editPortafolioPlataforma
      } : p)
    };
    
    saveUserProfileData(updatedProfile);
    setEditingPortafolio(null);
    triggerDynamicIsland("Portafolio", selectedLanguage === 'ES' ? "Activo actualizado" : "Asset updated", true);
    playTone('success', isMuted);
  };

  const handleBorrarTransaccion = (id: string, monto: number, tipo: string) => {
    requestConfirmation(
      "Eliminar movimiento",
      "¿Estás seguro de que quieres eliminar este movimiento?",
      () => {
        const filtered = transacciones.filter(t => t.id !== id);
        saveTransacciones(filtered);
        playTone('delete', isMuted);
        triggerDynamicIsland(
          "Movimiento Borrado", 
          `${tipo === 'Ingreso' ? '-' : '+'}$${monto.toLocaleString('es-ES')}`, 
          false
        );
      }
    );
  };

  const handleClearAll = () => {
    requestConfirmation(
      "Limpiar todo",
      "⚠️ ¿Estás seguro de que deseas eliminar TODOS los movimientos registrados?",
      () => {
        saveTransacciones([]);
        playTone('delete', isMuted);
        triggerDynamicIsland("Borrando todo", "La base de datos fue limpiada.", false);
      }
    );
  };

  const handleCargarEjemplo = () => {
    const demo: Transaccion[] = [
      {
        id: 'ex-1',
        tipo: 'Ingreso',
        monto: 4200,
        descripcion: 'Salario Recibido',
        fecha: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString()
      },
      {
        id: 'ex-2',
        tipo: 'Gasto',
        monto: 950,
        categoria: categorias.length > 0 ? categorias[0].nombre : 'Otros',
        descripcion: 'Abono Hipotecario',
        fecha: new Date(Date.now() - 4 * 24 * 3600 * 1000).toISOString()
      },
      {
        id: 'ex-3',
        tipo: 'Gasto',
        monto: 124,
        categoria: 'Alimentación',
        descripcion: 'Compra quincenal Alsuper',
        fecha: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString()
      },
      {
        id: 'ex-4',
        tipo: 'Gasto',
        monto: 85,
        categoria: 'Transporte',
        descripcion: 'Tarjeta recarga Metro',
        fecha: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString()
      },
      {
        id: 'ex-5',
        tipo: 'Gasto',
        monto: 340,
        categoria: 'Viajes',
        descripcion: 'Reserva Hotel Fin de Semana',
        fecha: new Date().toISOString()
      },
      {
        id: 'ex-6',
        tipo: 'Gasto',
        monto: 55,
        categoria: 'Compras',
        descripcion: 'Auriculares deportivos',
        fecha: new Date().toISOString()
      },
    ];
    saveTransacciones(demo);
    playTone('success', isMuted);
    triggerDynamicIsland("Datos de ejemplo", "Se cargaron 6 movimientos.", true);
  };

  const handleTap = () => {
    playTone('tap', isMuted);
  };

  const handleAddPortafolio = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nuevoPortafolio.nombre || !nuevoPortafolio.valor || !nuevoPortafolio.plataforma) {
      triggerDynamicIsland("Error", selectedLanguage === 'ES' ? "Todos los campos son obligatorios" : "All fields are required", false);
      return;
    }
    const val = parseFloat(nuevoPortafolio.valor.replace(/,/g, ''));
    if (isNaN(val) || val <= 0) {
      triggerDynamicIsland("Error", selectedLanguage === 'ES' ? "Valor inválido" : "Invalid value", false);
      return;
    }
    
    const newActivo = {
      id: `portafolio-${Date.now()}`,
      nombre: nuevoPortafolio.nombre,
      valor: val,
      plataforma: nuevoPortafolio.plataforma
    };
    
    const updatedProfile = {
      ...userProfile,
      portafolios: [...(userProfile.portafolios || []), newActivo]
    };
    saveUserProfileData(updatedProfile);
    setNuevoPortafolio({ nombre: '', valor: '', plataforma: '' });
    triggerDynamicIsland("Portafolio", selectedLanguage === 'ES' ? "Activo agregado" : "Asset added", true);
    playTone('success', isMuted);
  };

  const handleDeletePortafolio = (id: string) => {
    const updatedProfile = {
      ...userProfile,
      portafolios: (userProfile.portafolios || []).filter(p => p.id !== id)
    };
    saveUserProfileData(updatedProfile);
    triggerDynamicIsland("Portafolio", selectedLanguage === 'ES' ? "Activo eliminado" : "Asset removed", false);
    playTone('delete', isMuted);
  };

  const handleAddCategory = () => {
    if (!newCatName.trim()) {
      triggerDynamicIsland("Escribe nombre", "Ingresa un nombre para la categoría", false);
      return;
    }
    const nameExists = categorias.some(c => c.nombre.toLowerCase() === newCatName.trim().toLowerCase());
    if (nameExists) {
      triggerDynamicIsland("Ya existe", "Esta categoría ya se encuentra registrada", false);
      return;
    }
    const newCat = {
      nombre: newCatName.trim(),
      icon: newCatIcon,
      color: newCatColor
    };
    saveCategorias([...categorias, newCat]);
    setNewCatName('');
    triggerDynamicIsland("Añadida", `Categoría "${newCat.nombre}" agregada con éxito`, true);
    playTone('success', isMuted);
    
    // Smoothly close categories modal and navigate home
    setShowManageCategories(false);
    setActiveTab('finance');
  };

  const handleDeleteCategory = (nombre: string) => {
    if (nombre === 'Otros') {
      triggerDynamicIsland("No permitido", "La categoría de respaldo no se puede borrar", false);
      return;
    }
    requestConfirmation(
      "Eliminar Categoría",
      `¿Estás seguro de que quieres eliminar la categoría "${nombre}"?`,
      () => {
        const filtered = categorias.filter(c => c.nombre !== nombre);
        saveCategorias(filtered);
        triggerDynamicIsland("Eliminada", `Categoría "${nombre}" borrada`, false);
        playTone('delete', isMuted);
        
        // Smoothly close categories modal and navigate home
        setShowManageCategories(false);
        setActiveTab('finance');
      }
    );
  };

  const simulateCloudSync = () => {    playTone('voice', isMuted);
    triggerDynamicIsland("Finanzas Cloud", "Comenzando respaldo...", true);
    
    setTimeout(() => {      const now = new Date();
      
      playTone('success', isMuted);
      triggerDynamicIsland("Nube Actualizada", "Sincronización completa", true);
    }, 2000);
  };

  // Find max category value to scale progress indicators proportionally
  const montosDeCategorias = categorias.map(c => getCategoriaMonto(c.nombre));
  const maxCategoriaMonto = Math.max(...montosDeCategorias, 1);

  // Dynamic calculation of highest spending category for the Cloud AI predictions tab
  const getMajorGastoCat = (): { nombre: string; total: number; color: string; percentage: number } => {
    let maxVal = -1;
    let maxCat = 'Ninguno';
    let color = '#6B7280';
    
    categorias.forEach(c => {
      const v = getCategoriaMonto(c.nombre);
      if (v > maxVal) {
        maxVal = v;
        maxCat = c.nombre;
        color = c.color;
      }
    });

    const totalEgresos = totalPasivos;
    const pct = totalEgresos > 0 ? Math.round((maxVal / totalEgresos) * 100) : 0;
    
    return {
      nombre: maxCat,
      total: maxVal,
      color,
      percentage: pct
    };
  };

  const majorGasto = getMajorGastoCat();

  // App Main Render within optional Simulator Screen
  const renderAppContent = () => {
    if (isAppLocked) {
      return (
        <div id="ios-lock-screen" className="flex flex-col h-full bg-[#0d0e14] text-white p-6 justify-between relative overflow-y-auto">
          {lockIsScanning && (
            <div className="absolute inset-0 bg-[#0d0e14]/98 z-50 flex flex-col items-center justify-center p-6 space-y-4 animate-fade-in text-center">
              <div className="relative flex items-center justify-center w-28 h-28">
                {/* Scanning radar circles */}
                <div className="absolute inset-0 bg-teal-500 rounded-full animate-ping opacity-25" />
                <div className="absolute -inset-4 bg-teal-500/10 rounded-full animate-pulse opacity-20" />
                <div className="w-20 h-20 rounded-full border-4 border-dashed border-teal-500 animate-spin flex items-center justify-center bg-slate-900 shadow-xl relative animate-pulse">
                  <Fingerprint className="w-10 h-10 text-teal-400" />
                </div>
                <div className="absolute h-0.5 w-16 bg-teal-400 rounded-full top-[42%] left-[21%] animate-bounce shadow-[0_0_12px_rgba(45,212,191,0.8)]" />
              </div>
              <div className="space-y-1">
                <p className="text-sm font-black text-white uppercase tracking-widest">
                  {selectedLanguage === 'ES' ? 'Verificando Identidad...' : 'Confirming Identity...'}
                </p>
                <p className="text-xs text-slate-400 font-bold">
                  {selectedLanguage === 'ES' 
                    ? 'Iniciando módulo seguro FaceID / Biometría' 
                    : 'Initializing hardware enclave biometric scanner'}
                </p>
              </div>
            </div>
          )}

          {/* Header */}
          <div className="text-center pt-8 space-y-4">
            <div className="mx-auto w-16 h-16 bg-gradient-to-tr from-teal-500 to-[#312E81] rounded-2xl flex items-center justify-center shadow-lg border border-teal-400/30">
              <Shield className="w-8 h-8 text-teal-300 animate-pulse" />
            </div>
            <div>
              <h2 className="text-xl font-black tracking-tight">
                {selectedLanguage === 'ES' ? 'Acceso Seguro FinDream' : 'Secure Access FinDream'}
              </h2>
              <p className="text-xs font-bold text-teal-400 mt-1 uppercase tracking-widest">
                {userProfile.nombre ? `Hola, ${userProfile.nombre}` : (selectedLanguage === 'ES' ? 'Hola de nuevo' : 'Hello again')}
              </p>
            </div>
          </div>

          {/* Body Passcode / Password Form */}
          <div className="space-y-6 my-auto pt-6">
            <p className="text-[11px] text-center font-bold text-slate-400 leading-tight">
              {selectedLanguage === 'ES' 
                ? 'Ingresa tu contraseña de usuario o utiliza FaceID para ingresar' 
                : 'Enter your profile password or bypass with rapid biometrics scan'}
            </p>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                playTone('tap', isMuted);
                
                if (userProfile.contraseña && lockPasswordInput === userProfile.contraseña) {
                  setLockStatus({ type: 'success', text: selectedLanguage === 'ES' ? '¡Identidad Confirmada!' : 'Identity Confirmed!' });
                  playTone('success', isMuted);
                  setTimeout(() => {
                    setIsAppLocked(false);
                    setLockPasswordInput('');
                    setLockStatus({ type: '', text: '' });
                  }, 600);
                } else {
                  setLockStatus({ 
                    type: 'error', 
                    text: selectedLanguage === 'ES' 
                      ? 'Contraseña o PIN incorrecto. Inténtalo de nuevo.' 
                      : 'Incorrect passcode/password. Try again.' 
                  });
                  playTone('delete', isMuted);
                }
              }}
              className="space-y-4"
            >
              <div>
                <label className="text-[10px] uppercase font-black tracking-wider text-slate-400 block mb-1">
                  {selectedLanguage === 'ES' ? 'Contraseña o PIN de Seguridad' : 'Security Passcode / Password'}
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 text-xs">🔑</span>
                  <input
                    type="password"
                    required
                    placeholder={selectedLanguage === 'ES' ? 'Ingresa tu PIN / Clave' : 'Enter your key'}
                    value={lockPasswordInput}
                    onChange={(e) => setLockPasswordInput(e.target.value)}
                    className="w-full bg-slate-900/90 border border-slate-750 rounded-xl py-3 pl-10 pr-4 text-xs font-bold text-white focus:outline-none focus:ring-2 focus:ring-teal-550 focus:border-transparent text-center"
                  />
                </div>
              </div>

              {lockStatus.text && (
                <div className={`p-2.5 rounded-lg border text-center text-[10.5px] font-bold ${
                  lockStatus.type === 'success' 
                    ? 'bg-teal-950/40 border-teal-850 text-teal-400' 
                    : 'bg-rose-950/40 border-rose-950 text-rose-400'
                }`}>
                  {lockStatus.text}
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-teal-600 to-[#312E81] text-white font-black text-xs uppercase tracking-wider rounded-xl hover:opacity-95 shadow-lg active:scale-98 transition flex items-center justify-center gap-1.5 cursor-pointer text-center"
              >
                <Check className="w-4 h-4" />
                <span>{selectedLanguage === 'ES' ? 'Confirmar Identidad' : 'Confirm Identity'}</span>
              </button>
            </form>

            <div className="flex items-center gap-3 py-1">
              <hr className="flex-1 border-slate-800" />
              <span className="text-[8.5px] font-black text-slate-500 uppercase tracking-widest">
                {selectedLanguage === 'ES' ? 'Acceso rápido' : 'Fast Access'}
              </span>
              <hr className="flex-1 border-slate-800" />
            </div>

            {/* Quick biometric trigger */}
            <button
              type="button"
              onClick={() => {
                playTone('tap', isMuted);
                setLockIsScanning(true);
                setTimeout(() => {
                  setLockIsScanning(false);
                  playTone('success', isMuted);
                  setIsAppLocked(false);
                  triggerDynamicIsland(
                    selectedLanguage === 'ES' ? "FaceID Verificado" : "FaceID Verified",
                    selectedLanguage === 'ES' ? "Acceso concedido con éxito." : "Authorized successfully.",
                    true
                  );
                }, 1400);
              }}
              className="w-full py-3 bg-slate-905 hover:bg-slate-850 border border-slate-800 hover:border-teal-500/50 rounded-xl text-xs font-black text-teal-400 flex items-center justify-center gap-2.5 transition active:scale-97 cursor-pointer group"
            >
              <div className="relative">
                <Fingerprint className="w-5 h-5 text-teal-400 group-hover:scale-110 transition-all animate-pulse" />
                <ScanFace className="w-3.5 h-3.5 text-teal-300 absolute -bottom-1 -right-1 bg-slate-900 rounded-full p-0.2" />
              </div>
              <span>{selectedLanguage === 'ES' ? 'Ingresar con FaceID' : 'Log In with FaceID'}</span>
            </button>
          </div>

          {/* Footer brand info */}
          <div className="text-center pt-2 text-[10px] text-gray-400 space-y-1">
            <p>© Finanza FaceID Enclave Security.</p>
          </div>
        </div>
      );
    }

    return (
      <div id="ios-app-container" className="flex flex-col h-full bg-[#f4f5f9] text-gray-905 overflow-hidden relative">
      {/* iOS App Top Bar Style */}
      <div className="flex justify-between items-center px-5 pt-[calc(1.25rem+env(safe-area-inset-top,0px))] pb-3 bg-white border-b border-gray-100 sticky top-0 z-20 shadow-xs">
        <div className="flex items-center gap-2.5">
          {/* Detailed beautiful turquoise vector logo of FinDream attached reference */}
          <div className="relative w-11 h-11 flex items-center justify-center bg-white rounded-xl border border-teal-100 p-0.5 flex-shrink-0 shadow-xs">
            <FinDreamLogo size="sm" variant="icon-only" animated={false} />
          </div>
          <div>
            <h1 className="text-[17px] font-black tracking-tight text-slate-900 leading-tight">
              {activeTab === 'finance' 
                ? t('tab_resumen') 
                : activeTab === 'cloud' 
                  ? t('tab_sueno') 
                  : activeTab === 'productos' 
                    ? t('tab_productos') 
                    : t('tab_insights')}
            </h1>
          </div>
        </div>

        {/* --- COUNTRY, LANGUAGE AND USER PROFILE SECTION --- */}
        <div className="flex items-center gap-1.5 flex-shrink-0">
          {/* Country Selection Dropdown */}
          <div className="relative flex items-center bg-slate-50 hover:bg-slate-100 border border-slate-200/60 rounded-xl px-1.5 py-1 gap-1 shadow-2xs transition-colors">
            <span className="text-[10px] font-black text-slate-700 flex items-center gap-0.5">
              {selectedCountry === 'CO' ? '🇨🇴 COP' :
               selectedCountry === 'US' ? '🇺🇸 USD' :
               selectedCountry === 'ES' ? '🇪🇸 EUR' :
               '🇲🇽 MXN'}
            </span>
            <select
              value={selectedCountry}
              onChange={(e) => { handleTap(); setSelectedCountry(e.target.value as any); }}
              className="absolute inset-0 opacity-0 cursor-pointer text-[10px]"
            >
              <option value="CO">CO (COP)</option>
              <option value="US">US (USD)</option>
              <option value="ES">ES (EUR)</option>
              <option value="MX">MX (MXN)</option>
            </select>
          </div>

          {/* Language Selection Dropdown */}
          <div className="relative flex items-center bg-slate-50 hover:bg-slate-150 border border-slate-200/60 rounded-xl px-2 py-1 gap-1 shadow-2xs transition-colors">
            <span className="text-[10px] font-black text-slate-700">
              {selectedLanguage === 'ES' ? '🌐 ES' : '🌐 EN'}
            </span>
            <select
              value={selectedLanguage}
              onChange={(e) => { handleTap(); setSelectedLanguage(e.target.value as any); }}
              className="absolute inset-0 opacity-0 cursor-pointer text-[10px]"
            >
              <option value="ES">ES</option>
              <option value="EN">EN</option>
            </select>
          </div>

          {/* --- MI CUENTA BUTTON --- */}
          <button
            id="btn-mi-cuenta"
            onClick={() => { handleTap(); setIsCuentaOpen(true); }}
            className="flex items-center gap-1 px-2 py-1 bg-gradient-to-tr from-[#00897B]/5 to-[#00897B]/15 hover:from-[#00897B]/15 hover:to-[#00897B]/25 text-[#00796B] rounded-xl text-[10.5px] font-black tracking-tight transition-all cursor-pointer border border-[#00897B]/20 active:scale-95 shadow-sm"
          >
            <div className="w-4.5 h-4.5 rounded-full bg-[#00897B] text-white flex items-center justify-center font-bold text-[9px]">
              {userProfile.nombre ? userProfile.nombre.charAt(0).toUpperCase() : 'P'}
            </div>
            <span className="font-extrabold whitespace-nowrap">{t('mi_cuenta')}</span>
          </button>
        </div>
      </div>

      {/* Main Screen Scroll Viewport */}
      <div id="main-scroll-container" className="flex-1 overflow-y-auto no-scrollbar pb-16 relative">
        {activeTab === 'finance' ? (
          <div className="p-5 space-y-5">
            {/* --- FILTRO DE TIEMPO (Pill Slide iOS - NOW AT THE TOP CONSTRAINING EVERYTHING BELOW) --- */}
            <div id="filtro-tiempo" className="overflow-x-auto no-scrollbar pt-1">
              <div className="flex bg-gray-100 p-1 rounded-xl relative">
                {(['Día', 'Semana', 'Mes', 'Año', 'Histórico'] as FiltroTiempo[]).map((f) => {
                  const sel = filtroSeleccionado === f;
                  return (
                    <button
                      id={`btn-filtro-${f}`}
                      key={f}
                      onClick={() => { handleTap(); setFiltroSeleccionado(f); }}
                      className="relative flex-1 text-center py-2 text-xs font-semibold rounded-lg focus:outline-none transition-colors z-10 whitespace-nowrap px-3 cursor-pointer"
                      style={{ color: sel ? '#ffffff' : '#4B5563' }}
                    >
                      {sel && (
                        <motion.div
                          layoutId="activeFilterBg"
                          className="absolute inset-0 bg-[#312E81] rounded-lg -z-10 shadow-sm"
                          transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                        />
                      )}
                      {f}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* --- HEADER DE TOTALES (Solo una fila / iOS layout premium) --- */}
        <div id="totales-container" className="grid grid-cols-2 gap-3.5">
          {/* Activos */}
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-emerald-550 glass-card p-4 rounded-2xl shadow-sm text-white flex flex-col justify-between"
            style={{ backgroundImage: 'linear-gradient(135deg, #10B981, #059669)' }}
          >
            <div className="flex justify-between items-center w-full">
              <span className="text-[10px] font-black tracking-widest text-[#D1FAE5] uppercase">ACTIVOS TOTALES</span>
              <button 
                onClick={(e) => { e.stopPropagation(); handleTap(); setHideBalances(!hideBalances); }}
                className="p-1 -mr-1 text-emerald-100 hover:text-white hover:bg-white/15 rounded-lg transition cursor-pointer"
                title={hideBalances ? "Mostrar balance" : "Ocultar balance"}
              >
                {hideBalances ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
              </button>
            </div>
            <div className="mt-2.5">
              <span className="text-2xl font-extrabold block">
                {hideBalances ? "******" : `$${totalActivos.toLocaleString('es-ES', { minimumFractionDigits: 0 })}`}
              </span>
              <span className="text-[10px] text-emerald-100 flex items-center gap-1 mt-1">
                <TrendingUp className="w-3 h-3" /> ingresos vigentes
              </span>
            </div>
          </motion.div>
 
          {/* Pasivos */}
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-red-550 glass-card p-4 rounded-2xl shadow-sm text-white flex flex-col justify-between"
            style={{ backgroundImage: 'linear-gradient(135deg, #EF4444, #DC2626)' }}
          >
            <div className="flex justify-between items-center w-full">
              <span className="text-[10px] font-black tracking-widest text-[#FEE2E2] uppercase">PASIVOS TOTALES</span>
              <button 
                onClick={(e) => { e.stopPropagation(); handleTap(); setHideBalances(!hideBalances); }}
                className="p-1 -mr-1 text-red-100 hover:text-white hover:bg-white/15 rounded-lg transition cursor-pointer"
                title={hideBalances ? "Mostrar balance" : "Ocultar balance"}
              >
                {hideBalances ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
              </button>
            </div>
            <div className="mt-2.5">
              <span className="text-2xl font-extrabold block">
                {hideBalances ? "******" : `$${totalPasivos.toLocaleString('es-ES', { minimumFractionDigits: 0 })}`}
              </span>
              <span className="text-[10px] text-red-100 flex items-center gap-1 mt-1">
                <TrendingDown className="w-3 h-3" /> egresos calculados
              </span>
            </div>
          </motion.div>
        </div>
 
        {/* --- BALANCE GENERAL RESUMEN --- */}
        <div id="balance-resumen" className="bg-white p-4 rounded-2xl shadow-[0_2px_8px_rgba(0,0,0,0.03)] border border-gray-100">
          <div className="flex justify-between items-center text-xs text-gray-500 mb-1">
            <div className="flex items-center gap-1.5">
              <span>Balance de Operaciones ({filtroSeleccionado})</span>
              <button 
                onClick={(e) => { e.stopPropagation(); handleTap(); setHideBalances(!hideBalances); }}
                className="p-0.5 text-slate-400 hover:text-slate-600 rounded-md transition cursor-pointer"
                title={hideBalances ? "Mostrar balance" : "Ocultar balance"}
              >
                {hideBalances ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
              </button>
            </div>
            <span className="font-semibold text-gray-700">Progreso Gasto</span>
          </div>
          <div className="flex justify-between items-baseline mb-2">
            <span className={`text-2xl font-black ${totalActivos - totalPasivos >= 0 ? 'text-slate-900' : 'text-rose-600'}`}>
              {hideBalances ? "******" : `$${(totalActivos - totalPasivos).toLocaleString('es-ES', { minimumFractionDigits: 0 })}`}
            </span>
            <span className="text-xs font-semibold text-rose-600">
              {totalActivos > 0 ? `${Math.min(Math.round((totalPasivos / totalActivos) * 100), 100)}%` : '0%'}
            </span>
          </div>
          <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
            <div 
              className={`h-full rounded-full transition-all duration-500 ${totalActivos - totalPasivos >= 0 ? 'bg-indigo-600' : 'bg-rose-500'}`}
              style={{ width: `${totalActivos > 0 ? Math.min((totalPasivos / totalActivos) * 100, 100) : 0}%` }}
            />
          </div>
        </div>

        {/* --- DYNAMIC PIE/DONUT CHART CARD --- */}
        {(() => {
          const totalGastosFiltrados = categorias.reduce((sum, c) => sum + getCategoriaMonto(c.nombre), 0);
          
          let cumulativePercentage = 0;
          const slicesData = categorias.map((c) => {
            const val = getCategoriaMonto(c.nombre);
            const percentage = totalGastosFiltrados > 0 ? (val / totalGastosFiltrados) * 100 : 0;
            const currentOffset = -cumulativePercentage;
            cumulativePercentage += percentage;
            return {
              ...c,
              monto: val,
              percentage,
              offset: currentOffset,
            };
          }).filter(s => s.monto > 0);

          return (
            <div className="bg-white rounded-2xl p-5 shadow-[0_2px_12px_rgba(0,0,0,0.03)] border border-gray-105 space-y-4 text-left">
              <div className="flex flex-col text-left">
                <h3 className="text-xs font-black text-slate-800 tracking-wider block uppercase">Análisis de Gastos</h3>
                <span className="text-[10px] text-slate-400 font-semibold mt-0.5">Distribución porcentual por categoría ({filtroSeleccionado})</span>
              </div>

              {totalGastosFiltrados === 0 ? (
                <div className="py-8 px-4 text-center bg-slate-50 border border-dashed border-slate-200 rounded-xl space-y-2">
                  <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400">
                    <PieChart className="w-5 h-5" />
                  </div>
                  <p className="text-xs font-bold text-slate-500">No hay gastos en {filtroSeleccionado} para graficar</p>
                  <p className="text-[9.5px] text-slate-400 font-semibold leading-tight">Registra egresos para ver la gráfica interactiva</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
                  {/* Interactive Recharts Donut */}
                  <div className="md:col-span-12 lg:col-span-5 flex justify-center relative h-[220px]">
                    <div className="w-full h-full absolute inset-0">
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsPieChart>
                          <Pie
                            data={slicesData}
                            cx="50%"
                            cy="50%"
                            innerRadius={45}
                            outerRadius={70}
                            paddingAngle={2}
                            dataKey="monto"
                            nameKey="nombre"
                            onMouseEnter={(_, index) => setHoveredSlice(slicesData[index].nombre)}
                            onMouseLeave={() => setHoveredSlice(null)}
                            labelLine={true}
                            label={({ cx, cy, midAngle, innerRadius, outerRadius, value, name, percent, payload }) => {
                              const RADIAN = Math.PI / 180;
                              // Place label outside the pie chart
                              const radius = outerRadius + 22; 
                              const x = cx + radius * Math.cos(-midAngle * RADIAN);
                              const y = cy + radius * Math.sin(-midAngle * RADIAN);
                              if (percent < 0.03) return null; // Don't show labels for tiny slices
                              return (
                                <text 
                                  x={x} 
                                  y={y} 
                                  fill="#475569" 
                                  textAnchor={x > cx ? 'start' : 'end'} 
                                  dominantBaseline="central" 
                                  className="text-[9.5px] md:text-[10px] font-extrabold" 
                                  style={{ pointerEvents: 'none' }}
                                >
                                  {`${payload.nombre} ${(percent * 100).toFixed(0)}%`}
                                </text>
                              );
                            }}
                          >
                            {slicesData.map((entry, index) => (
                              <Cell 
                                key={`cell-${index}`} 
                                fill={entry.color} 
                                stroke={hoveredSlice === entry.nombre ? '#fff' : 'transparent'}
                                strokeWidth={hoveredSlice === entry.nombre ? 2 : 0}
                                style={{
                                  outline: 'none',
                                  transition: 'all 300ms ease',
                                  transformOrigin: 'center',
                                  transform: hoveredSlice === entry.nombre ? 'scale(1.05)' : 'scale(1)',
                                }}
                              />
                            ))}
                          </Pie>
                        </RechartsPieChart>
                      </ResponsiveContainer>
                    </div>
                    
                    {/* Hole text in the middle */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center px-4">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider block truncate max-w-[80px]">
                        {hoveredSlice ? hoveredSlice : (selectedLanguage === 'ES' ? 'Total Gasto' : 'Total Expense')}
                      </span>
                      <span className="text-xs font-black text-slate-800 mt-0.5 block truncate max-w-full">
                        ${(hoveredSlice 
                          ? getCategoriaMonto(hoveredSlice) 
                          : totalGastosFiltrados
                        ).toLocaleString('es-ES', { minimumFractionDigits: 0 })}
                      </span>
                    </div>
                  </div>

                  {/* Legend on the Right */}
                  <div className="md:col-span-12 lg:col-span-7 space-y-1.5 w-full">
                    {slicesData.map((slice) => {
                      const isHovered = hoveredSlice === slice.nombre;
                      return (
                        <div 
                          key={slice.nombre}
                          onMouseEnter={() => setHoveredSlice(slice.nombre)}
                          onMouseLeave={() => setHoveredSlice(null)}
                          className={`flex items-center justify-between p-1.5 px-2 rounded-xl transition-all border duration-200 cursor-pointer ${
                            isHovered ? 'bg-slate-50 border-slate-200/60 shadow-3xs scale-[1.01]' : 'border-transparent'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            {/* Custom Dot indicating category color */}
                            <div 
                              className="w-2 rounded-full flex-shrink-0 aspect-square" 
                              style={{ backgroundColor: slice.color }}
                            />
                            <span className="text-[10.5px] font-bold text-slate-700">
                              {slice.nombre}
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5 text-right flex-shrink-0">
                            <span className="text-[10.5px] font-black text-slate-800">
                              ${slice.monto.toLocaleString('es-ES', { minimumFractionDigits: 0 })}
                            </span>
                            <span className="text-[9px] font-black text-slate-450 bg-slate-100 px-1.5 py-0.2 rounded-full min-w-8 text-center block">
                              {Math.round(slice.percentage)}%
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          );
        })()}

        {/* --- GRID DE CATEGORÍAS (Visual Metrics) --- */}
        <div className="space-y-3.5">
          <div className="flex justify-between items-center">
            <h3 className="text-xs font-extrabold text-black tracking-wider block uppercase">
              {selectedLanguage === 'ES' ? 'Categorías de Gasto' : 'Expense Categories'}
            </h3>
            <button
              onClick={() => { handleTap(); setShowManageCategories(true); }}
              className="text-[10px] font-bold text-white bg-indigo-600 hover:bg-indigo-700 px-3 rounded-lg py-1.5 transition-all shadow-sm cursor-pointer border border-indigo-700"
            >
              {selectedLanguage === 'ES' ? '⚙️ Personalizar' : '⚙️ Customise'}
            </button>
          </div>

          <div id="grid-categorias" className="grid grid-cols-2 gap-3.5">
            {categorias.map((c) => {
              const val = getCategoriaMonto(c.nombre);
              const progressPercentage = Math.min((val / maxCategoriaMonto) * 100, 100);

              return (
                <motion.div
                  key={c.nombre}
                  whileTap={{ scale: 0.98 }}
                  className="bg-white rounded-2xl p-4 shadow-[0_2px_8px_rgba(0,0,0,0.02)] border border-gray-100 flex flex-col justify-between min-h-[110px]"
                >
                  <div className="flex justify-between items-start">
                    <div className="p-2 rounded-xl bg-gray-50">
                      {renderCategoriaIcon(c.icon, c.color, "w-5.5 h-5.5")}
                    </div>
                    <span className="text-[10px] font-black text-slate-800 uppercase tracking-tight text-right shrink-1">
                      {translateCategory(c.nombre)}
                    </span>
                  </div>

                  <div className="mt-4 text-left">
                    <div className="flex justify-between items-baseline mb-1">
                      <span className="text-xs text-slate-700 font-bold">
                        {selectedLanguage === 'ES' ? 'Monto' : 'Amount'}
                      </span>
                      <span className="text-[15px] font-black text-slate-800">
                        ${val.toLocaleString('es-ES', { minimumFractionDigits: 0 })}
                      </span>
                    </div>

                    {/* Proportional custom bar indicator from Flutter */}
                    <div className="w-full bg-slate-50 h-1.5 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${val > 0 ? progressPercentage : 0}%` }}
                        transition={{ duration: 0.6 }}
                        className="h-full rounded-full"
                        style={{ backgroundColor: c.color }}
                      />
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* --- RECENT TRANSACTIONS LOG (Highly polished list, swipeable deletion) --- */}
        <div className="space-y-3 pt-2">
          <div className="flex flex-col gap-3">
            <div className="flex justify-between items-center">
              <h3 className="text-xs font-black text-slate-800 tracking-wider block uppercase">Historial de Movimientos</h3>
              {transacciones.length > 0 && (
                <button 
                  id="btn-clear-all"
                  onClick={handleClearAll}
                  className="text-[10px] font-extrabold text-rose-700 hover:text-rose-800 bg-rose-50 hover:bg-rose-100 px-2.5 py-1 rounded-lg transition-colors cursor-pointer border border-rose-100"
                >
                  {selectedLanguage === 'ES' ? 'Limpiar datos' : 'Clear data'}
                </button>
              )}
            </div>

            {/* --- ORDENAR POR (Sorting iOS Control) --- */}
            <div className="flex bg-gray-100 p-1 rounded-xl relative w-full mb-2">
              <button
                type="button"
                onClick={() => { handleTap(); setOrdenSeleccionado('MasReciente'); }}
                className="relative flex-1 text-center py-1.5 text-[10px] font-bold rounded-lg focus:outline-none transition-colors z-10 px-2 cursor-pointer"
                style={{ color: ordenSeleccionado === 'MasReciente' ? '#ffffff' : '#4B5563' }}
              >
                {ordenSeleccionado === 'MasReciente' && (
                  <motion.div
                    layoutId="activeSortBg"
                    className="absolute inset-0 bg-[#312E81] rounded-lg -z-10 shadow-sm"
                    transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                  />
                )}
                {selectedLanguage === 'ES' ? 'Más recientes' : 'Newest First'}
              </button>
              <button
                type="button"
                onClick={() => { handleTap(); setOrdenSeleccionado('MayorGasto'); }}
                className="relative flex-1 text-center py-1.5 text-[10px] font-bold rounded-lg focus:outline-none transition-colors z-10 px-2 cursor-pointer"
                style={{ color: ordenSeleccionado === 'MayorGasto' ? '#ffffff' : '#4B5563' }}
              >
                {ordenSeleccionado === 'MayorGasto' && (
                  <motion.div
                    layoutId="activeSortBg"
                    className="absolute inset-0 bg-[#312E81] rounded-lg -z-10 shadow-sm"
                    transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                  />
                )}
                {selectedLanguage === 'ES' ? 'Mayor a menor' : 'Highest Amount'}
              </button>
            </div>
          </div>

          <div id="lista-transacciones" className="space-y-2.5">
            {transaccionesFiltradasLista.length === 0 ? (
              <div className="bg-white border rounded-2xl p-6 text-center text-slate-700 border-dashed border-slate-300">
                <Clock className="w-8 h-8 text-indigo-400 mx-auto mb-2 animate-bounce" />
                <p className="text-sm font-black text-slate-800">
                  {selectedLanguage === 'ES' 
                    ? `No hay movimientos registrados en ${filtroSeleccionado}` 
                    : `No movements registered in ${filtroSeleccionado}`}
                </p>
                <p className="text-[10.5px] text-slate-700 font-bold mt-1">
                  {selectedLanguage === 'ES' 
                    ? 'Presiona el botón "+" o "Demo" para comenzar.' 
                    : 'Press the "+" or "Demo" button to start.'}
                </p>
              </div>
            ) : (
              <AnimatePresence initial={false}>
                {transaccionesFiltradasLista.map((t) => {
                  const isExpense = t.tipo === 'Gasto';
                  const cat = isExpense ? (categorias.find(c => c.nombre === t.categoria) || CATEGORIAS_PREDEFINIDAS.find(c => c.nombre === t.categoria)) : null;
                  const itemColor = isExpense ? (cat?.color || '#312E81') : '#10B981';

                  return (
                    <motion.div
                      key={t.id}
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="bg-white rounded-xl p-3.5 shadow-sm border border-gray-50 flex justify-between items-center group hover:bg-slate-50 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        {/* Transaction Icon Indicator */}
                        <div 
                          className="w-10 h-10 rounded-xl flex items-center justify-center animate-pulse"
                          style={{ backgroundColor: `${itemColor}12` }}
                        >
                          {isExpense ? (
                            renderCategoriaIcon(cat?.icon || 'MoreHorizontal', itemColor, "w-5.5 h-5.5")
                          ) : (
                            <TrendingUp className="w-5 h-5 text-emerald-600" />
                          )}
                        </div>

                        {/* Title & category / date */}
                        <div>
                          <div className="text-xs font-black text-slate-800 block line-clamp-1">
                            {t.descripcion}
                          </div>
                          <span className="text-[9.5px] text-slate-800 flex flex-wrap items-center gap-1.5 mt-1 font-extrabold">
                            {isExpense ? (
                              <>
                                <span 
                                  className="px-1.5 py-0.5 rounded-md text-[8px] font-black text-white uppercase tracking-wider" 
                                  style={{ backgroundColor: itemColor }}
                                >
                                  {translateCategory(t.categoria || 'Otros')}
                                </span>
                                {t.formaPago && (
                                  <span className="px-1.5 py-0.5 rounded-md text-[8.5px] font-black bg-slate-100 text-slate-800 border border-slate-200 uppercase tracking-tight">
                                    💳 {t.formaPago}
                                  </span>
                                )}
                              </>
                            ) : (
                              <>
                                <span className="px-1.5 py-0.5 rounded-md text-[8px] font-black text-white uppercase tracking-wider bg-emerald-600">
                                  {selectedLanguage === 'ES' ? 'INGRESO' : 'INCOME'}
                                </span>
                                {t.formaPago && (
                                  <span className="px-1.5 py-0.5 rounded-md text-[8.5px] font-black bg-emerald-50 text-emerald-900 border border-emerald-150 uppercase tracking-tight">
                                    💰 {t.formaPago}
                                  </span>
                                )}
                              </>
                            )}
                            <span className="text-slate-600 font-bold">
                              • {formatSafeDateString(t.fecha).toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })}
                            </span>
                          </span>
                        </div>
                      </div>

                      {/* Right amount and delete operations */}
                      <div className="flex items-center gap-2">
                        <span className={`text-sm font-black whitespace-nowrap ${isExpense ? 'text-rose-700' : 'text-emerald-700'}`}>
                          {isExpense ? '-' : '+'}${t.monto.toLocaleString('es-ES', { minimumFractionDigits: 0 })}
                        </span>

                        {/* Edit Transaction Trigger */}
                        <button
                          id={`btn-editar-${t.id}`}
                          onClick={() => { handleTap(); setEditingTransaction(t); }}
                          className="p-1 px-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all cursor-pointer border border-transparent hover:border-indigo-100"
                          title="Editar movimiento"
                        >
                          <MoreHorizontal className="w-4 h-4 text-slate-700 font-extrabold" />
                        </button>

                        {/* Delete Trigger */}
                        <button
                          id={`btn-borrar-${t.id}`}
                          onClick={() => handleBorrarTransaccion(t.id, t.monto, t.tipo)}
                          className="p-1 px-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-all cursor-pointer"
                          title="Eliminar movimiento"
                        >
                          <Trash className="w-4 h-4" />
                        </button>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            )}
          </div>
        </div>

            {/* Minimal info brand footer */}
            <div className="text-center pt-2 text-[10px] text-gray-400 space-y-1">
              <p>© Finanza Insight iOS 17 Simulator Engine.</p>
              <p className="flex items-center justify-center gap-1">
                Reconocimiento de Inteligencia por <span className="font-semibold text-[#00897B]">Google Gemini API Workspace</span>
              </p>
            </div>
          </div>
        ) : activeTab === 'cloud' ? (
          <div id="dream-tab-content" className="p-5 space-y-5 text-left flex-1 flex flex-col justify-between">
            <div className="space-y-5">
              <DreamComplianceChart
                suenos={suenos}
                activeSuenoId={activeSuenoId}
                realAhorroNeto={realAhorroNeto}
                totalActivos={totalActivos}
                totalPasivos={totalPasivos}
                selectedCountry={selectedCountry}
                selectedLanguage={selectedLanguage}
                onSelectSueno={handleSelectSueno}
                onAddSueno={handleAddSueno}
                onUpdateSueno={handleUpdateSueno}
                onDeleteSueno={handleDeleteSueno}
                transacciones={transacciones}
              />
            </div>

            {/* Minimal info brand footer */}
            <div className="text-center pt-2 text-[10px] text-gray-400 space-y-0.5 pb-10 mt-4">
              <p>© Finanza Insight Sueño 17 Live View.</p>
              <p className="flex items-center justify-center gap-1">
                Visualización de proyección de metas y curva de cumplimiento
              </p>
            </div>
          </div>
        ) : activeTab === 'productos' ? (
          /* --- PRODUCTOS INTEGRATION TAB VIEW --- */
          <div id="productos-tab-content" className="p-5 space-y-5 text-left flex-1 flex flex-col justify-between">
            <div className="space-y-5">
              {/* iOS Segmented Control */}
              <div className="bg-slate-100 p-1 rounded-2xl flex items-center justify-between border border-slate-200">
                <button
                  onClick={() => { handleTap(); setActiveProductSubTab('actuales'); }}
                  className={`flex-1 text-center py-2 text-xs font-black rounded-xl transition cursor-pointer ${
                    activeProductSubTab === 'actuales'
                      ? 'bg-white text-[#00897B] shadow-sm'
                      : 'text-slate-500 hover:text-slate-700'
                  }`}
                >
                  💳 {t('productos_actuales')}
                </button>
                <button
                  onClick={() => { handleTap(); setActiveProductSubTab('recomendaciones'); }}
                  className={`flex-1 text-center py-2 text-xs font-black rounded-xl transition flex items-center justify-center gap-1 cursor-pointer ${
                    activeProductSubTab === 'recomendaciones'
                      ? 'bg-white text-[#00897B] shadow-sm'
                      : 'text-slate-500 hover:text-slate-700'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" /> {t('recomendaciones_ai')}
                </button>
              </div>

              {activeProductSubTab === 'actuales' ? (
                /* --- A) PRODUCTOS ACTUALES --- */
                (() => {
                  const filteredList = (userProfile.productos || []).filter(p => matchesFilter(p, portfolioFilter));
                  const totalCupo = filteredList.reduce((sum, p) => sum + (p.montoTotal || 0), 0);
                  const totalConsumido = filteredList.reduce((sum, p) => sum + getProductUtilizado(p), 0);
                  const consumidoPct = totalCupo > 0 ? Math.min(100, Math.round((totalConsumido / totalCupo) * 105), 100) : 0; // Wait, let's use standard 100 limit:
                  const pctSafe = totalCupo > 0 ? Math.min(100, Math.round((totalConsumido / totalCupo) * 100)) : 0;
                  return (
                    <div className="space-y-4">
                      {/* --- PROGRESS BAR GAUGE: TOTAL VS CONSUMIDO WITH FILTER SELECTOR --- */}
                      <div className="bg-gradient-to-tr from-[#0F172A] to-[#1E293B] text-white rounded-3xl p-5 shadow-lg space-y-4 border border-slate-800">
                        <div className="flex justify-between items-center pb-2 border-b border-slate-800/80">
                          <div className="space-y-0.5 text-left">
                            <span className="text-[9px] font-black uppercase text-teal-400 tracking-widest block">Resumen de Cupos</span>
                            <h4 className="text-xs font-black text-slate-100">Consumo General de Portafolio</h4>
                          </div>
                          <div className="text-right">
                            <span className="text-[10px] font-black text-teal-400 bg-teal-950/55 border border-teal-800/40 px-2.5 py-0.5 rounded-full select-none">
                              {pctSafe}% Usado
                            </span>
                          </div>
                        </div>

                        {/* Progress Gauge */}
                        <div className="space-y-2">
                          <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden p-[2px] border border-slate-800 shadow-inner">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${pctSafe}%` }}
                              className="h-full bg-gradient-to-r from-teal-400 via-emerald-400 to-amber-500 rounded-full"
                              transition={{ duration: 0.8 }}
                            />
                          </div>
                          <div className="flex justify-between items-center text-xs">
                            <div className="flex flex-col text-left">
                              <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Consumido / Deuda</span>
                              <span className="font-extrabold text-[#F1F5F9]">${totalConsumido.toLocaleString('es-ES', { minimumFractionDigits: 0 })}</span>
                            </div>
                            <div className="flex flex-col text-right">
                              <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Cupo / Límite Total</span>
                              <span className="font-extrabold text-[#F1F5F9]">${totalCupo.toLocaleString('es-ES', { minimumFractionDigits: 0 })}</span>
                            </div>
                          </div>
                        </div>

                        {/* Category Selector Buttons */}
                        <div className="grid grid-cols-4 gap-1.5 pt-1">
                          {[
                            { id: 'all', label: selectedLanguage === 'ES' ? 'Todo' : 'All' },
                            { id: 'debit', label: selectedLanguage === 'ES' ? 'T. Débito' : 'Debit' },
                            { id: 'credit', label: selectedLanguage === 'ES' ? 'T. Crédito' : 'Credit' },
                            { id: 'credits', label: selectedLanguage === 'ES' ? 'Créditos' : 'Loans' },
                          ].map((btn) => (
                            <button
                              key={btn.id}
                              type="button"
                              onClick={() => {
                                handleTap();
                                setPortfolioFilter(btn.id as any);
                              }}
                              className={`py-1.5 px-0.5 rounded-xl text-[9px] font-black uppercase tracking-wider transition-all border text-center cursor-pointer ${
                                portfolioFilter === btn.id
                                  ? 'bg-teal-400 border-teal-400 text-slate-950 shadow-sm font-black'
                                  : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:bg-slate-800/80'
                              }`}
                            >
                              {btn.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Explanatory introduction card */}
                      <div className="bg-white rounded-3xl p-4 shadow-[0_4px_16px_rgba(0,0,0,0.01)] border border-slate-100 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <div className="p-2.5 bg-teal-50 text-[#00897B] rounded-xl flex-shrink-0 animate-pulse">
                            <CreditCard className="w-5 h-5" />
                          </div>
                          <div className="text-left">
                            <h4 className="text-xs font-black text-slate-800 uppercase tracking-widest">{t('productos_vigentes')}</h4>
                            <p className="text-[10px] text-slate-400 font-semibold leading-tight">{t('vincular_pagos')}</p>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => { handleTap(); setShowAddProductTab(!showAddProductTab); }}
                          className={`p-2 rounded-xl border-2 transition-all cursor-pointer flex items-center justify-center ${
                            showAddProductTab
                              ? 'bg-rose-50 border-rose-200 text-rose-600'
                              : 'bg-teal-50 border-teal-200 text-teal-700'
                          }`}
                        >
                          {showAddProductTab ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                        </button>
                      </div>

                      {/* Add Product Form - Darkened colors and high contrast to avoid pale styling */}
                      {showAddProductTab && (
                        <form className="bg-white rounded-2xl border border-slate-350 p-4 space-y-4 shadow-sm" onSubmit={(e) => {
                          e.preventDefault();
                          const bankSel = (document.getElementById('prod-tab-bank-select') as HTMLSelectElement)?.value || COLOMBIAN_BANKS[0];
                          const typeSel = (document.getElementById('prod-tab-type-select') as HTMLSelectElement)?.value || PRODUCT_TAB_DEBTS_ONLY[0];
                          const franchiseSel = (document.getElementById('prod-tab-franchise-select') as HTMLSelectElement)?.value || COLOMBIAN_FRANCHISES[0];
                          const aliasVal = (document.getElementById('prod-tab-alias-input') as HTMLInputElement)?.value?.trim();
                          const totalVal = parseFloat((document.getElementById('prod-tab-total-input') as HTMLInputElement)?.value) || 0;
                          const usedVal = parseFloat((document.getElementById('prod-tab-used-input') as HTMLInputElement)?.value) || 0;

                          const newProd: ProductoFinanciero = {
                            id: `prod-tab-${Date.now()}`,
                            banco: bankSel,
                            tipo: typeSel,
                            alias: aliasVal || undefined,
                            montoTotal: totalVal > 0 ? totalVal : undefined,
                            montoUtilizado: totalVal > 0 && usedVal >= 0 ? usedVal : undefined,
                            franquicia: (franchiseSel && franchiseSel !== 'Ninguna / No Aplica') ? franchiseSel : undefined
                          };

                          const updatedProds = [...(userProfile.productos || []), newProd];
                          saveUserProfileData({ ...userProfile, productos: updatedProds });
                          playTone('success', isMuted);
                          triggerDynamicIsland(
                            selectedLanguage === 'ES' ? "Portafolio Agregado" : "Portfolio Added", 
                            `${bankSel} • ${typeSel}`, 
                            true
                          );

                          // Reset controls
                          const aliasEl = document.getElementById('prod-tab-alias-input') as HTMLInputElement;
                          if (aliasEl) aliasEl.value = '';
                          const totalEl = document.getElementById('prod-tab-total-input') as HTMLInputElement;
                          if (totalEl) totalEl.value = '';
                          const usedEl = document.getElementById('prod-tab-used-input') as HTMLInputElement;
                          if (usedEl) usedEl.value = '';
                          const franchiseEl = document.getElementById('prod-tab-franchise-select') as HTMLSelectElement;
                          if (franchiseEl) franchiseEl.value = COLOMBIAN_FRANCHISES[0];
                        }}>
                        <div className="bg-slate-100/90 p-4 rounded-xl border border-slate-350 space-y-3 text-left">
                          <span className="text-[10px] font-black uppercase text-[#004D40] tracking-wider block">
                            {t('registrar_producto')}
                          </span>
                          
                          <div className="grid grid-cols-2 gap-2">
                            {/* Selector de Bancos */}
                            <div className="col-span-2 sm:col-span-1">
                              <label className="text-[9.5px] font-black text-slate-800 uppercase block mb-0.5">{t('banco_co')}</label>
                              <select
                                id="prod-tab-bank-select"
                                className="w-full bg-white border border-slate-400 rounded-lg py-1.5 px-2 text-[11px] font-black text-slate-950 focus:outline-none focus:border-teal-600 focus:ring-1 focus:ring-teal-600 transition"
                              >
                                {COLOMBIAN_BANKS.map((b) => (
                                  <option key={b} value={b} className="text-slate-950 font-bold">{b}</option>
                                ))}
                              </select>
                            </div>

                            {/* Selector de Tipo de Producto */}
                            <div className="col-span-2 sm:col-span-1">
                              <label className="text-[9.5px] font-black text-slate-800 uppercase block mb-0.5">{t('tipo_producto')}</label>
                              <select
                                id="prod-tab-type-select"
                                className="w-full bg-white border border-slate-400 rounded-lg py-1.5 px-2 text-[11px] font-black text-slate-950 focus:outline-none focus:border-teal-600 focus:ring-1 focus:ring-teal-600 transition"
                              >
                                {PRODUCT_TAB_DEBTS_ONLY.map((p) => (
                                  <option key={p} value={p} className="text-slate-950 font-bold">
                                    {translateProduct(p, selectedLanguage)}
                                  </option>
                                ))}
                              </select>
                            </div>

                            {/* Selector de Franquicia (Opcional) */}
                            <div className="col-span-2">
                              <label className="text-[9.5px] font-black text-slate-800 uppercase block mb-0.5">
                                {selectedLanguage === 'ES' ? 'Franquicia (Tarjeta) - Opcional' : 'Franchise (Card) - Optional'}
                              </label>
                              <select
                                id="prod-tab-franchise-select"
                                className="w-full bg-white border border-slate-400 rounded-lg py-1.5 px-2 text-[11px] font-black text-slate-950 focus:outline-none focus:border-teal-600 focus:ring-1 focus:ring-teal-600 transition"
                              >
                                {COLOMBIAN_FRANCHISES.map((f) => (
                                  <option key={f} value={f} className="text-slate-950 font-bold">
                                    {translateFranchise(f, selectedLanguage)}
                                  </option>
                                ))}
                              </select>
                            </div>
                          </div>

                          {/* Cupo / Monto Total & Consumido input grid */}
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="text-[9.5px] font-black text-slate-800 uppercase block mb-0.5">
                                {selectedLanguage === 'ES' ? 'Cupo / Monto Total (COP)' : 'Total Limit / Amount (COP)'}
                              </label>
                              <input
                                type="number"
                                id="prod-tab-total-input"
                                placeholder="Ej: 10000000"
                                className="w-full bg-white border border-slate-400 rounded-lg py-1.5 px-2 text-[11px] font-black text-slate-950 placeholder:text-slate-500 focus:outline-none focus:border-teal-600 focus:ring-1 focus:ring-teal-600 transition"
                              />
                            </div>
                            <div>
                              <label className="text-[9.5px] font-black text-slate-800 uppercase block mb-0.5">
                                {selectedLanguage === 'ES' ? 'Utilizado / Pagado (COP)' : 'Used / Paid (COP)'}
                              </label>
                              <input
                                type="number"
                                id="prod-tab-used-input"
                                placeholder="Ej: 1000000"
                                className="w-full bg-white border border-slate-400 rounded-lg py-1.5 px-2 text-[11px] font-black text-slate-950 placeholder:text-slate-500 focus:outline-none focus:border-teal-600 focus:ring-1 focus:ring-teal-600 transition"
                              />
                            </div>
                          </div>

                          {/* Alias input */}
                          <div>
                            <label className="text-[9.5px] font-black text-slate-800 uppercase block mb-0.5">{t('alias_opcional')}</label>
                            <input
                              type="text"
                              id="prod-tab-alias-input"
                               placeholder={selectedLanguage === 'ES' ? 'Ej: Cuenta de Nómina, Tarjeta Principal' : 'i.e. Salary Account, Main Card'}
                              className="w-full bg-white border border-slate-400 rounded-lg py-1.5 px-2 text-[11px] font-black text-slate-950 placeholder:text-slate-400 focus:outline-none focus:border-teal-600 focus:ring-1 focus:ring-teal-600 transition"
                            />
                          </div>

                          <button
                            type="submit"
                            className="w-full py-2 bg-[#00897B] hover:bg-[#00796B] text-white font-black text-xs uppercase tracking-wider rounded-lg shadow-md transition active:scale-98 cursor-pointer text-center mt-1"
                          >
                            + {t('guardar_producto')}
                          </button>
                        </div>
                        </form>
                      )}

                        {/* List of active products - with high contrast darken styles */}
                        <div className="space-y-3 text-left">
                          <span className="text-[10px] font-black uppercase text-slate-800 tracking-wider block">
                            {t('productos_vigentes')} ({filteredList.length})
                          </span>
                          
                          {(!userProfile.productos || userProfile.productos.length === 0) ? (
                            <div className="p-4 text-center bg-slate-50 rounded-2xl text-[11px] text-slate-400 font-medium border border-slate-200">
                              {t('sin_productos')}
                            </div>
                          ) : filteredList.length === 0 ? (
                            <div className="p-4 text-center bg-slate-50 rounded-2xl text-[11.5px] text-slate-600 font-black border border-dashed border-slate-300">
                              {selectedLanguage === 'ES' ? 'No hay productos que coincidan con esta categoría.' : 'No products match this category.'}
                            </div>
                          ) : (
                            <div className="space-y-3">
                              {filteredList.map((prod) => (
                                <div key={prod.id} className="p-4 bg-white hover:bg-slate-50 rounded-2xl border border-slate-350 shadow-xs transition-all flex flex-col space-y-3">
                                  <div className="flex justify-between items-center w-full">
                                    <div className="flex items-center gap-2.5">
                                      <div className="p-1.5 bg-teal-50 rounded-lg text-[#00897B] flex-shrink-0 border border-teal-100/50">
                                        <CreditCard className="w-4 h-4" />
                                      </div>
                                      <div className="text-left">
                                        <span className="text-xs font-black text-slate-900 block leading-tight text-left">
                                          {prod.banco}{" "}
                                          <span className="font-extrabold text-[#00796B] text-[10px] bg-teal-50 px-2 py-0.5 rounded-full border border-teal-200/50">
                                            {translateProduct(prod.tipo, selectedLanguage)}
                                          </span>
                                          {prod.franquicia && (
                                            <span className="font-extrabold text-blue-800 text-[10px] bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200/50 ml-1">
                                              {translateFranchise(prod.franquicia, selectedLanguage)}
                                            </span>
                                          )}
                                        </span>
                                        {prod.alias && (
                                          <span className="text-[9.5px] text-[#005B4F] font-black mt-0.5 block italic text-left">
                                            "{prod.alias}"
                                          </span>
                                        )}
                                      </div>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const filtered = (userProfile.productos || []).filter(p => p.id !== prod.id);
                                        saveUserProfileData({ ...userProfile, productos: filtered });
                                        playTone('delete', isMuted);
                                        triggerDynamicIsland(
                                          selectedLanguage === 'ES' ? "Portafolio Eliminado" : "Portfolio Removed", 
                                          `${prod.banco} Eliminado`, 
                                          false
                                        );
                                      }}
                                      className="p-1.5 text-rose-600 hover:text-rose-800 hover:bg-rose-50 rounded-lg transition-all cursor-pointer border border-transparent hover:border-rose-100"
                                      title="Eliminar Portafolio"
                                    >
                                      <Trash2 className="w-4 h-4" />
                                    </button>
                                  </div>

                                  {/* Progress bar visual for Total vs Used */}
                                  {prod.montoTotal && prod.montoTotal > 0 ? (
                                    <div className="pt-2 border-t border-slate-300 w-full space-y-1.5">
                                      <div className="flex justify-between items-baseline text-[10.5px]">
                                        <span className="font-bold text-slate-700">
                                          {selectedLanguage === 'ES' ? 'Utilizado/Pagado: ' : 'Used/Paid: '}
                                          <strong className="text-slate-900 font-extrabold">
                                            ${getProductUtilizado(prod).toLocaleString('es-ES', { minimumFractionDigits: 0 })}
                                          </strong>
                                          <span className="mx-1 text-slate-400">/</span>
                                          <strong className="text-[#00897B] font-extrabold">
                                            ${prod.montoTotal.toLocaleString('es-ES', { minimumFractionDigits: 0 })}
                                          </strong>
                                        </span>
                                        <span className="font-black text-[#00897B] bg-teal-50 px-1.5 py-0.2 rounded-md border border-teal-100/65">
                                          {Math.min(Math.round((getProductUtilizado(prod) / prod.montoTotal) * 100), 100)}%
                                        </span>
                                      </div>
                                      <div className="w-full bg-slate-200/80 h-2 rounded-full overflow-hidden relative border border-slate-300">
                                        <motion.div
                                          initial={{ width: 0 }}
                                          animate={{ width: `${Math.min((getProductUtilizado(prod) / prod.montoTotal) * 100, 100)}%` }}
                                          className="h-full bg-gradient-to-r from-[#00897B] via-teal-500 to-emerald-500 rounded-full"
                                          transition={{ duration: 0.6 }}
                                        />
                                      </div>
                                    </div>
                                  ) : null}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })()
              ) : (
                /* --- B) RECOMENDACIONES AI --- */
                <div className="space-y-4">
                  {/* Sub-tab selection inside Recommendations section */}
                  <div className="flex bg-slate-100 p-1 rounded-xl gap-1 border border-slate-300">
                    <button
                      type="button"
                      onClick={() => { handleTap(); setRecommendationMode('consulting'); }}
                      className={`flex-1 text-center py-2 text-[11px] font-black rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer ${
                        recommendationMode === 'consulting'
                          ? 'bg-white text-[#00897B] shadow-xs'
                          : 'text-slate-500 hover:text-slate-700'
                      }`}
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      {selectedLanguage === 'ES' ? 'Preguntar a IA ✨' : 'Ask AI ✨'}
                    </button>
                    <button
                      type="button"
                      onClick={() => { handleTap(); setRecommendationMode('automatic'); }}
                      className={`flex-1 text-center py-2 text-[11px] font-black rounded-lg transition-all flex items-center justify-center gap-1 cursor-pointer ${
                        recommendationMode === 'automatic'
                          ? 'bg-white text-[#00897B] shadow-xs'
                          : 'text-slate-500 hover:text-slate-700'
                      }`}
                    >
                      <Zap className="w-3.5 h-3.5 animate-pulse" />
                      {selectedLanguage === 'ES' ? 'Auto Recomendaciones 🤖' : 'Auto Suggestions 🤖'}
                    </button>
                  </div>

                  {recommendationMode === 'consulting' ? (
                    /* =======================================================
                       PART 1: INTERACTIVE CUSTOM PRODUCT SEARCH WITH GEMINI
                       ======================================================= */
                    <div className="space-y-4">
                      {/* Interactive prompt block */}
                      <div className="bg-white rounded-3xl p-5 shadow-[0_4px_20px_rgba(0,0,0,0.02)] border border-[#00897B]/10 text-left space-y-4">
                        <div className="border-b border-slate-100 pb-2.5">
                          <span className="text-[9.5px] font-black uppercase tracking-widest text-[#008B81] flex items-center gap-1">
                            <Sparkles className="w-3.5 h-3.5 animate-pulse" /> {selectedLanguage === 'ES' ? 'CONSULTORÍA INTERACTIVA' : 'INTERACTIVE CONSULTATION'}
                          </span>
                          <h3 className="text-sm font-black text-slate-900 mt-1">
                            {selectedLanguage === 'ES' ? '¿Qué producto financiero buscas?' : 'What financial product are you seeking?'}
                          </h3>
                          <p className="text-[10px] text-slate-450 font-medium leading-relaxed">
                            {selectedLanguage === 'ES' 
                              ? 'Dile a la IA tus necesidades específicas (bajas tasas, sin costo, cashback) en tu país y te sugerirá las mejores opciones.' 
                              : 'Specify your needs (low rates, no fees, cashback) in your country and the AI will recommend prime choices.'}
                          </p>
                        </div>

                        {/* Search tags for 1-click execution */}
                        <div className="space-y-1.5">
                          <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider block">
                            {selectedLanguage === 'ES' ? 'Sugerencias de búsqueda rápidas:' : 'Quick search ideas:'}
                          </span>
                          <div className="flex flex-wrap gap-1.5">
                            {[
                              { label: selectedLanguage === 'ES' ? 'Sin Cuota de Manejo 💳' : 'No Annual Fee Card 💳', query: selectedLanguage === 'ES' ? 'Busco una tarjeta de crédito sin cuota de manejo' : 'Looking for a credit card with absolutely no annual handling fees' },
                              { label: selectedLanguage === 'ES' ? 'CDT Alta Rentabilidad 📈' : 'High Yield CDT 📈', query: selectedLanguage === 'ES' ? 'Quiero ver opciones de CDT a 90 o 180 días con las mejores tasas de interés' : 'What are the best high yield CDTs or savings certificates around 90-180 days?' },
                              { label: selectedLanguage === 'ES' ? 'Cuenta con Cashback 💰' : 'Cashback Checking Account 💰', query: selectedLanguage === 'ES' ? 'Busco una cuenta de ahorros que devuelva dinero por comprar' : 'Seeking a digital savings account that offers cashback on daily purchases' },
                              { label: selectedLanguage === 'ES' ? 'Fintech de Bajo Interés 📱' : 'Low Interest Fintech 📱', query: selectedLanguage === 'ES' ? 'Busco un crédito rápido de bajo costo o cooperativa transparente' : 'Recommend digital loans or fintech services with transparent fast approval' }
                            ].map((tag, idx) => (
                              <button
                                key={idx}
                                type="button"
                                onClick={() => {
                                  handleTap();
                                  setCustomProductQuery(tag.query);
                                  handleCustomProductSearch(tag.query);
                                }}
                                className="px-2.5 py-1 text-[10px] font-extrabold text-slate-900 bg-slate-200 hover:bg-slate-300 hover:text-teal-950 rounded-lg transition-all cursor-pointer border border-slate-450 hover:border-teal-400 shadow-xs"
                              >
                                {tag.label}
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* Textarea lookup field with Speech-To-Text / Voice input support */}
                        <form
                          onSubmit={(e) => {
                            e.preventDefault();
                            if (!customProductQuery.trim()) return;
                            handleCustomProductSearch(customProductQuery);
                          }}
                          className="space-y-3"
                        >
                          <div className="relative">
                            <textarea
                              rows={3}
                              value={customProductQuery}
                              onChange={(e) => setCustomProductQuery(e.target.value)}
                              placeholder={selectedLanguage === 'ES' ? "Ej. Busco una tarjeta de crédito sin cuota de manejo que acumule puntos para viajes ..." : "e.g. Looking for a credit card with zero monthly handling fees that accumulates travel miles..."}
                              className="w-full bg-slate-50 border border-slate-400 rounded-xl p-3 pr-10 text-xs font-bold text-slate-950 focus:outline-[#008B81] focus:ring-1 focus:ring-[#008B81] placeholder:text-slate-500 transition-all leading-normal"
                            />
                            <button
                              type="button"
                              onClick={startCustomProductSpeechRecognition}
                              className={`absolute right-2.5 bottom-2.5 p-2 rounded-xl transition-all cursor-pointer ${
                                isListeningCustomProduct
                                  ? 'bg-rose-500 text-white animate-pulse shadow-md ring-2 ring-rose-300'
                                  : 'bg-slate-200 hover:bg-slate-300 text-slate-700 hover:text-slate-950 hover:scale-105 border border-slate-300'
                              }`}
                              title={selectedLanguage === 'ES' ? "Activar dictado por voz 🎙️" : "Toggle voice dictation 🎙️"}
                            >
                              <Mic className={`w-4 h-4 ${isListeningCustomProduct ? 'animate-bounce' : ''}`} />
                            </button>
                          </div>

                          {customProductError && (
                            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-[10.5px] font-bold">
                              ⚠️ {customProductError}
                            </div>
                          )}

                          <button
                            type="submit"
                            disabled={isSearchingCustomProducts || !customProductQuery.trim()}
                            className="w-full py-3 bg-[#00897B] hover:bg-[#00796B] disabled:opacity-50 text-white font-black text-xs uppercase tracking-wider rounded-xl shadow-md transition active:scale-98 cursor-pointer flex items-center justify-center gap-2"
                          >
                            {isSearchingCustomProducts ? (
                              <>
                                <Loader2 className="w-4 h-4 animate-spin text-white" />
                                <span>{selectedLanguage === 'ES' ? 'Preguntando a la IA...' : 'Analyse Options with AI...'}</span>
                              </>
                            ) : (
                              <>
                                <Sparkles className="w-4 h-4 text-white animate-pulse" />
                                <span>{selectedLanguage === 'ES' ? 'Sugerir con Inteligencia Artificial ✨' : 'Generate suggestions with AI ✨'}</span>
                              </>
                            )}
                          </button>
                        </form>
                      </div>

                      {/* Search Results loop */}
                      {isSearchingCustomProducts && (
                        <div className="p-10 text-center space-y-3 bg-white/75 rounded-3xl border border-slate-200">
                          <Loader2 className="w-7 h-7 animate-spin mx-auto text-[#00897B]" />
                          <p className="text-xs font-black text-slate-800 uppercase tracking-widest">{selectedLanguage === 'ES' ? 'Analizando mercado local' : 'Scanning local financial market'}</p>
                          <p className="text-[10px] text-slate-500 font-semibold">{selectedLanguage === 'ES' ? 'Buscando las mejores ofertas bancarias en internet...' : 'Mapping bank policies, interest rates, and fee waivers...'}</p>
                        </div>
                      )}

                      {!isSearchingCustomProducts && customProductRecommendations && (
                        <div className="space-y-4">
                          <div className="flex justify-between items-center px-1">
                            <span className="text-[10px] font-black uppercase text-slate-400 tracking-wider">
                              {selectedLanguage === 'ES' ? 'Opciones sugeridas por la IA' : 'AI generated matches'}
                            </span>
                            <button
                              type="button"
                              onClick={() => setCustomProductRecommendations(null)}
                              className="text-[10px] text-slate-500 hover:text-rose-600 font-bold transition"
                            >
                              {selectedLanguage === 'ES' ? 'Limpiar resultados ✕' : 'Clear matches ✕'}
                            </button>
                          </div>

                          <div className="space-y-3.5">
                            {customProductRecommendations.length === 0 ? (
                              <div className="p-8 text-center bg-white rounded-3xl border border-dashed border-slate-350 text-xs font-semibold text-slate-500">
                                {selectedLanguage === 'ES' ? 'No se encontraron ofertas viables para esta consulta. Intenta cambiar de palabras clave.' : 'No matches found. Try broadening your criteria.'}
                              </div>
                            ) : (
                              customProductRecommendations.map((rec) => {
                                const alreadyLinked = userProfile.productos?.some(p => p.alias === rec.producto && p.banco === rec.banco);
                                return (
                                  <motion.div
                                    key={rec.id}
                                    initial={{ opacity: 0, y: 12 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className="bg-white rounded-3xl p-5 shadow-[0_4px_20px_rgba(0,0,0,0.02)] border border-[#00897B]/10 hover:border-[#00897B]/25 transition relative overflow-hidden text-left"
                                  >
                                    <span className="absolute top-0 right-0 bg-gradient-to-l from-indigo-600 to-[#00897B] text-white font-black text-[7.5px] uppercase tracking-widest px-2.5 py-1 rounded-bl-xl shadow-xs">
                                      AI MATCHED ⭐
                                    </span>

                                    <div className="space-y-3">
                                      {/* Bank and Product */}
                                      <div>
                                        <span className="text-[9px] font-extrabold uppercase text-[#00796B] tracking-wider block bg-[#E0F2F1]/40 px-2 py-0.5 rounded-md inline-block">
                                          🏛️ {rec.banco}
                                        </span>
                                        <h2 className="text-sm font-black text-slate-900 mt-1.5 leading-snug">
                                          {rec.producto}
                                        </h2>
                                      </div>

                                      {/* Cost card */}
                                      <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-150 flex justify-between items-center text-xs">
                                        <span className="text-slate-500 font-bold">{selectedLanguage === 'ES' ? 'Costo de Manejo:' : 'Handling Fee:'}</span>
                                        <strong className="text-indigo-900 font-black">{rec.costoMensual}</strong>
                                      </div>

                                      {/* AI explanation */}
                                      <p className="text-[10.5px] text-slate-600 bg-indigo-50/25 p-3 rounded-xl border border-indigo-150/10 italic leading-normal">
                                        💡 <strong>AI Reason:</strong> {rec.razon}
                                      </p>

                                      {/* Benefits list */}
                                      <div className="space-y-1.5">
                                        <span className="text-[9.5px] font-black uppercase text-slate-400 tracking-widest block">{t('beneficios')}</span>
                                        <ul className="space-y-1 text-[11px] text-slate-705">
                                          {rec.beneficios.map((ben, bIdx) => (
                                            <li key={bIdx} className="flex items-start gap-1.5">
                                              <span className="text-[#00897B] mt-0.5 flex-shrink-0">✓</span>
                                              <span className="leading-tight font-medium text-slate-700">{ben}</span>
                                            </li>
                                          ))}
                                        </ul>
                                      </div>

                                      {/* Portfolio quick link action button */}
                                      <div className="pt-2 border-t border-slate-100">
                                        {alreadyLinked ? (
                                          <button
                                            type="button"
                                            disabled
                                            className="w-full py-2 bg-emerald-50 text-emerald-700 border border-emerald-250 font-black text-[10.5px] uppercase tracking-wider rounded-xl cursor-not-allowed flex items-center justify-center gap-1"
                                          >
                                            <Check className="w-3.5 h-3.5 stroke-[3px]" />
                                            <span>{selectedLanguage === 'ES' ? 'Vinculado al Portafolio ✅' : 'Linked to active portfolio ✅'}</span>
                                          </button>
                                        ) : (
                                          <button
                                            type="button"
                                            onClick={() => handleLinkRecommendedProduct(rec)}
                                            className="w-full py-2 bg-[#00897B] hover:bg-[#00796B] text-white font-black text-[10.5px] uppercase tracking-wider rounded-xl cursor-pointer transition active:scale-97 flex items-center justify-center gap-1 shadow-xs"
                                          >
                                            + {selectedLanguage === 'ES' ? 'Vincular a mis Productos' : 'Link to active portfolio'}
                                          </button>
                                        )}
                                      </div>
                                    </div>
                                  </motion.div>
                                );
                              })
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    /* =======================================================
                       PART 2: AUTOMATIC PRODUCTS SUGGESTED BY TRANSACTION RULES
                       ======================================================= */
                    <div className="space-y-4">
                      {/* Explanatory introduction card */}
                      <div className="bg-white rounded-3xl p-4 shadow-[0_4px_16px_rgba(0,0,0,0.01)] border border-slate-100 flex items-center gap-3">
                        <div className="p-2.5 bg-amber-50 text-amber-600 rounded-xl flex-shrink-0">
                          <Sparkles className="w-5 h-5 animate-pulse" />
                        </div>
                        <div>
                          <h4 className="text-xs font-black text-slate-800 uppercase tracking-widest text-left">{t('recomendaciones_ai')}</h4>
                          <p className="text-[10px] text-slate-400 font-semibold leading-tight text-left">{t('sincronizado_ai')}</p>
                        </div>
                      </div>

                      {/* Recommendations Generator call & loop */}
                      <div className="space-y-3.5">
                        {getRecommendedProducts(transacciones, userProfile.productos || [], selectedCountry, selectedLanguage).map((rec, index) => {
                          const alreadyLinked = userProfile.productos?.some(p => p.alias === rec.producto && p.banco === rec.banco);
                          return (
                            <motion.div
                              key={rec.id}
                              initial={{ opacity: 0, y: 12 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: index * 0.1 }}
                              className="bg-white rounded-3xl p-5 shadow-[0_4px_20px_rgba(0,0,0,0.02)] border border-[#00897B]/10 hover:border-[#00897B]/25 transition relative overflow-hidden text-left"
                            >
                              {/* Dynamic Top Badge for VIP sense */}
                              <span className="absolute top-0 right-0 bg-gradient-to-l from-[#00897B] to-[#00BFA5] text-white font-black text-[7.5px] uppercase tracking-widest px-2.5 py-1 rounded-bl-xl shadow-xs">
                                {selectedLanguage === 'ES' ? 'AUTOMÁTICO' : 'AUTO MATCH'}
                              </span>

                              <div className="space-y-3">
                                {/* Header section with Bank and Product */}
                                <div>
                                  <span className="text-[9px] font-extrabold uppercase text-[#00796B] tracking-wider block bg-[#E0F2F1]/40 px-2 py-0.5 rounded-md inline-block">
                                    🏛️ {rec.banco}
                                  </span>
                                  <h2 className="text-sm font-black text-slate-900 mt-1.5 leading-snug">
                                    {rec.producto}
                                  </h2>
                                </div>

                                {/* Dynamic Cost info */}
                                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-150 flex justify-between items-center text-xs">
                                  <span className="text-slate-500 font-bold">{t('costo_mensual')}:</span>
                                  <strong className="text-indigo-900 font-black">{rec.costoMensual}</strong>
                                </div>

                                {/* Reason based on expenses */}
                                <p className="text-[10.5px] text-slate-600 bg-teal-50/20 p-3 rounded-xl border border-teal-150/10 italic leading-normal">
                                  💡 <strong>AI Insights:</strong> {rec.razon}
                                </p>

                                {/* Bullet Benefits list */}
                                <div className="space-y-1.5">
                                  <span className="text-[9.5px] font-black uppercase text-slate-400 tracking-widest block">{t('beneficios')}</span>
                                  <ul className="space-y-1 text-[11px] text-slate-705">
                                    {rec.beneficios.map((ben, bIdx) => (
                                      <li key={bIdx} className="flex items-start gap-1.5">
                                        <span className="text-[#00897B] mt-0.5 flex-shrink-0">✓</span>
                                        <span className="leading-tight font-medium text-slate-700">{ben}</span>
                                      </li>
                                    ))}
                                  </ul>
                                </div>

                                {/* Portfolio quick link action button */}
                                <div className="pt-2 border-t border-slate-100">
                                  {alreadyLinked ? (
                                    <button
                                      type="button"
                                      disabled
                                      className="w-full py-2 bg-emerald-50 text-emerald-700 border border-emerald-250 font-black text-[10.5px] uppercase tracking-wider rounded-xl cursor-not-allowed flex items-center justify-center gap-1"
                                    >
                                      <Check className="w-3.5 h-3.5 stroke-[3px]" />
                                      <span>{selectedLanguage === 'ES' ? 'Vinculado al Portafolio ✅' : 'Linked to active portfolio ✅'}</span>
                                    </button>
                                  ) : (
                                    <button
                                      type="button"
                                      onClick={() => handleLinkRecommendedProduct(rec)}
                                      className="w-full py-2 bg-[#00897B] hover:bg-[#00796B] text-white font-black text-[10.5px] uppercase tracking-wider rounded-xl cursor-pointer transition active:scale-97 flex items-center justify-center gap-1 shadow-xs"
                                    >
                                      + {selectedLanguage === 'ES' ? 'Vincular a mis Productos' : 'Link to active portfolio'}
                                    </button>
                                  )}
                                </div>
                              </div>
                            </motion.div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Minimal info brand footer */}
            <div className="text-center pt-2 text-[10px] text-gray-400 space-y-0.5 pb-10 mt-4">
              <p>© Finanza Insight Products Hub.</p>
              <p className="flex items-center justify-center gap-1">
                Sincronización automatizada optimizada por <span className="font-semibold text-[#00897B]">Gemini Smart AI Engine</span>
              </p>
            </div>
          </div>
        ) : activeTab === 'portafolios' ? (
          /* --- PORTAFOLIO TAB VIEW --- */
          <div id="portafolios-tab-content" className="flex-1 flex flex-col h-[calc(100vh-190px)] mb-6 overflow-y-auto bg-slate-50 p-4 space-y-6">
            {/* Header Totals */}
            <div className="bg-gradient-to-br from-[#0F172A] to-[#1E293B] p-5 rounded-3xl shadow-lg border border-slate-800 text-white relative overflow-hidden shrink-0">
              <div className="absolute -top-4 -right-4 p-4 opacity-10">
                <Briefcase className="w-32 h-32" />
              </div>
              <h3 className="text-[10px] font-black uppercase tracking-widest text-[#94A3B8] mb-1 relative z-10">{selectedLanguage === 'ES' ? 'Total Activos' : 'Total Assets'}</h3>
              <p className="text-3xl font-black tracking-tight relative z-10">
                {formatCurrency((userProfile.portafolios || []).reduce((acc, p) => acc + p.valor, 0))}
              </p>
            </div>

            {/* Added Assets List */}
            <div className="space-y-4">
              <h3 className="text-xs font-black uppercase tracking-widest text-[#00897B]">{selectedLanguage === 'ES' ? 'Mis Activos' : 'My Assets'}</h3>
              {(userProfile.portafolios || []).length === 0 ? (
                <div className="bg-white p-6 rounded-2xl border border-slate-200 border-dashed text-center">
                  <p className="text-xs font-semibold text-slate-500">{selectedLanguage === 'ES' ? 'Aún no tienes activos en tu portafolio.' : 'You have no assets in your portfolio yet.'}</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-3">
                  {(userProfile.portafolios || []).map(p => (
                    <motion.div key={p.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-black text-slate-900">{p.nombre}</h4>
                        <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1 mt-0.5"><Database className="w-3 h-3" /> {p.plataforma}</p>
                      </div>
                      <div className="text-right flex items-center gap-3">
                        <span className="text-sm font-black text-indigo-700">{formatCurrency(p.valor)}</span>
                        <div className="flex bg-slate-50 border border-slate-200 rounded-lg overflow-hidden relative z-20">
                          <button onClick={() => { handleTap(); startEditingPortafolio(p); }} className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 transition cursor-pointer border-r border-slate-200"><MoreHorizontal className="w-4 h-4" /></button>
                          <button onClick={() => { handleTap(); handleDeletePortafolio(p.id); }} className="p-2 text-rose-400 hover:text-rose-600 hover:bg-slate-100 transition cursor-pointer"><Trash2 className="w-4 h-4" /></button>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>

            {/* Add Form */}
            <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm space-y-4 mb-4 shrink-0">
              <h3 className="text-[11px] font-black uppercase tracking-widest text-slate-800 flex items-center gap-2"><Plus className="w-4 h-4 text-[#00897B]" /> {selectedLanguage === 'ES' ? 'Agregar Activo' : 'Add Asset'}</h3>
              <form onSubmit={handleAddPortafolio} className="space-y-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">{selectedLanguage === 'ES' ? 'Nombre del activo' : 'Asset Name'}</label>
                  <input type="text" value={nuevoPortafolio.nombre} onChange={e => setNuevoPortafolio({...nuevoPortafolio, nombre: e.target.value})} placeholder={selectedLanguage === 'ES' ? "Ej. Bitcoin, Acciones..." : "e.g. Bitcoin, Stocks..."} className="w-full mt-1 p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#00897B]/20 transition" required />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">{selectedLanguage === 'ES' ? 'Valor' : 'Value'}</label>
                  <input type="text" inputMode="numeric" value={nuevoPortafolio.valor} onChange={e => setNuevoPortafolio({...nuevoPortafolio, valor: e.target.value.replace(/[^0-9.]/g, '')})} placeholder="$ 0" className="w-full mt-1 p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#00897B]/20 transition" required />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">{selectedLanguage === 'ES' ? 'Plataforma' : 'Platform'}</label>
                  <input type="text" value={nuevoPortafolio.plataforma} onChange={e => setNuevoPortafolio({...nuevoPortafolio, plataforma: e.target.value})} placeholder={selectedLanguage === 'ES' ? "Ej. Binance, Trii..." : "e.g. Binance, Trii..."} className="w-full mt-1 p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#00897B]/20 transition" required />
                </div>
                <button type="submit" className="w-full py-3 bg-[#00897B] text-white font-black text-xs uppercase tracking-widest rounded-xl hover:bg-[#00796B] transition cursor-pointer active:scale-97 shadow-sm mt-2">
                  {selectedLanguage === 'ES' ? 'Guardar Activo' : 'Save Asset'}
                </button>
              </form>
            </div>
          </div>
        ) : activeTab === 'insights' ? (
          /* --- INSIGHTS AI CHATBOT TAB VIEW --- */
          <div id="insights-tab-content" className="flex-1 flex flex-col h-[calc(100vh-190px)] mb-6 overflow-hidden bg-slate-50/50 p-4 space-y-4">
            
            {/* iOS Segmented Control for Insights Subtabs */}
            <div className="bg-slate-100 p-1 rounded-2xl flex items-center justify-between border border-slate-200 shrink-0">
              <button
                onClick={() => { handleTap(); setActiveInsightSubTab('asesor'); }}
                className={`flex-1 text-center py-2 text-xs font-black rounded-xl transition flex items-center justify-center gap-1 cursor-pointer ${
                  activeInsightSubTab === 'asesor'
                    ? 'bg-white text-[#00897B] shadow-sm'
                    : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" /> Asesor IA
              </button>
              <button
                onClick={() => { handleTap(); setActiveInsightSubTab('insights'); }}
                className={`flex-1 text-center py-2 text-xs font-black rounded-xl transition flex items-center justify-center gap-1 cursor-pointer ${
                  activeInsightSubTab === 'insights'
                    ? 'bg-white text-[#00897B] shadow-sm'
                    : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                💡 Insights
              </button>
            </div>

            {activeInsightSubTab === 'asesor' ? (
                            <ChatPanel
                selectedLanguage={selectedLanguage}
                selectedCountry={selectedCountry}
                userProfile={userProfile}
                suenos={suenos}
                activeSuenoId={activeSuenoId}
                totalActivos={totalActivos}
                totalPasivos={totalPasivos}
                transacciones={transacciones}
                saveTransacciones={saveTransacciones}
                saveUserProfileData={saveUserProfileData}
                setSuenos={setSuenos}
                triggerDynamicIsland={triggerDynamicIsland}
                playTone={playTone}
                isMuted={isMuted}
                t={t}
              />
            ) : (
              /* --- B) INSIGHTS VIEW (Moved from Sueño tab) --- */
              <div className="flex-1 overflow-y-auto pr-1 py-1 text-left space-y-4">
                {majorGasto.total > 0 ? (
                  <div className="bg-white rounded-3xl p-5 shadow-[0_4px_16px_rgba(0,0,0,0.02)] border border-gray-100 space-y-3">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
                        <Sparkles className="w-4 h-4 animate-pulse" />
                      </div>
                      <div>
                        <h4 className="text-xs font-black text-slate-800 uppercase tracking-widest">{t('optimizar_sueno')}</h4>
                        <p className="text-[9px] text-slate-400">Recomendaciones personalizadas</p>
                      </div>
                    </div>

                    <div className="space-y-2 text-xs">
                      <p className="text-[11px] text-slate-600 leading-relaxed">
                        {t('consejo_gasto')} <strong className="text-slate-800">{translateCategory(majorGasto.nombre)}</strong> con <strong className="text-slate-800">{formatCurrency(majorGasto.total)}</strong> ({majorGasto.percentage}% del total).
                      </p>
                      <p className="text-[11.5px] text-[#00897B] font-semibold bg-[#E0F2F1]/30 p-3 rounded-xl border border-[#00897B]/10 leading-relaxed">
                        💡 <strong>{t('consejo_ahorro')}:</strong> {t('consejo_ahorro_desc', { cat: translateCategory(majorGasto.nombre), amount: formatCurrency(Math.round(majorGasto.total * 0.15)) })}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-8 bg-slate-100 rounded-2xl flex flex-col items-center">
                    <span className="text-3xl mb-3">🤓</span>
                    <h3 className="text-sm font-bold text-slate-700">Sin datos para analizar</h3>
                    <p className="text-xs text-slate-500 mt-2">Registra gastos para comenzar a recibir insights personalizados de la IA.</p>
                  </div>
                )}
              </div>
            )}
          </div>
        ) : null}
      </div>

      {/* --- FLOATING PREMIUM iOS BOTTOM TAB BAR --- */}
      {/* Floating Action Button (Moved to bottom right to avoid overlap with 5 tabs) */}
      <div className="absolute bottom-[calc(5rem+env(safe-area-inset-bottom,0px))] right-5 z-40">
        <button
          id="btn-center-plus"
          onMouseDown={startPressLong}
          onMouseUp={endPressLong}
          onMouseLeave={cancelPressLong}
          onTouchStart={startPressLong}
          onTouchEnd={(e) => { e.preventDefault(); endPressLong(e); }}
          className="w-14 h-14 bg-gradient-to-tr from-[#00897B] to-[#00BFA5] rounded-2xl flex items-center justify-center shadow-lg shadow-teal-500/30 text-white transform hover:scale-105 active:scale-95 duration-200 cursor-pointer select-none"
          title="Presiona para elegir; mantén presionado para dictar con voz"
        >
          <Plus className="w-7 h-7 stroke-[3px]" />
        </button>
      </div>

      <div className="absolute bottom-0 inset-x-0 h-[calc(4rem+env(safe-area-inset-bottom,0px))] pb-[env(safe-area-inset-bottom,0px)] bg-white/95 backdrop-blur-md border-t border-gray-150 flex items-center justify-between z-30 shadow-[0_-4px_12px_rgba(0,0,0,0.03)] px-4">
        {/* Leftmost Tab: Registros de Ingresos y Egresos */}
        <button
          id="tab-btn-finance"
          onClick={() => { handleTap(); setActiveTab('finance'); document.getElementById('main-scroll-container')?.scrollTo({ top: 0, behavior: 'smooth' }); }}
          className={`flex-1 flex flex-col items-center justify-center py-1 transition-all cursor-pointer ${activeTab === 'finance' ? 'text-[#00897B]' : 'text-slate-400'}`}
        >
          <Database className="w-5.5 h-5.5 stroke-[2.5px]" />
          <span className="text-[10px] font-black mt-1 uppercase tracking-tight">
            {t('tab_resumen')}
          </span>
        </button>

        {/* Tab 2: Mi Sueño */}
        <button
          id="tab-btn-cloud"
          onClick={() => { handleTap(); setActiveTab('cloud'); document.getElementById('main-scroll-container')?.scrollTo({ top: 0, behavior: 'smooth' }); }}
          className={`flex-1 flex flex-col items-center justify-center py-1 transition-all cursor-pointer ${activeTab === 'cloud' ? 'text-[#00897B]' : 'text-slate-400'}`}
        >
          <Cloud className="w-5.5 h-5.5 stroke-[2.5px]" />
          <span className="text-[10px] font-black mt-1 uppercase tracking-tight">
            {t('tab_sueno')}
          </span>
        </button>

        {/* Tab 3: Productos */}
        <button
          id="tab-btn-productos"
          onClick={() => { handleTap(); setActiveTab('productos'); document.getElementById('main-scroll-container')?.scrollTo({ top: 0, behavior: 'smooth' }); }}
          className={`flex-1 flex flex-col items-center justify-center py-1 transition-all cursor-pointer ${activeTab === 'productos' ? 'text-[#00897B]' : 'text-slate-400'}`}
        >
          <CreditCard className="w-5.5 h-5.5 stroke-[2.5px]" />
          <span className="text-[10px] font-black mt-1 uppercase tracking-tight">
            {t('tab_productos')}
          </span>
        </button>

        {/* Tab 4: Portafolio */}
        <button
          id="tab-btn-portafolio"
          onClick={() => { handleTap(); setActiveTab('portafolios'); document.getElementById('main-scroll-container')?.scrollTo({ top: 0, behavior: 'smooth' }); }}
          className={`flex-1 flex flex-col items-center justify-center py-1 transition-all cursor-pointer ${activeTab === 'portafolios' ? 'text-[#00897B]' : 'text-slate-400'}`}
        >
          <Briefcase className="w-5.5 h-5.5 stroke-[2.5px]" />
          <span className="text-[10px] font-black mt-1 uppercase tracking-tight">
            {t('tab_portafolio')}
          </span>
        </button>

        {/* Rightmost Tab: AI Insights Chatbot */}
        <button
          id="tab-btn-insights"
          onClick={() => { handleTap(); setActiveTab('insights'); document.getElementById('main-scroll-container')?.scrollTo({ top: 0, behavior: 'smooth' }); }}
          className={`flex-1 flex flex-col items-center justify-center py-1 transition-all cursor-pointer ${activeTab === 'insights' ? 'text-[#00897B]' : 'text-slate-400'}`}
        >
          <Sparkles className="w-5.5 h-5.5 stroke-[2.5px] animate-pulse" />
          <span className="text-[10px] font-black mt-1 uppercase tracking-tight">
            {t('tab_insights')}
          </span>
        </button>
      </div>

      {/* --- ADDING DIALOG/BOTTOM SHEET (Aesthetic Apple iOS-style drawer modal bottom sheet) --- */}
      <AnimatePresence>
        {showManageCategories && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowManageCategories(false)}
              className="absolute inset-0 bg-black/60 z-40 backdrop-blur-[2px]"
            />

            {/* Modal Body */}
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 24, stiffness: 220 }}
              className="absolute bottom-0 inset-x-0 bg-white rounded-t-[30px] z-50 p-6 shadow-2xl flex flex-col border-t border-slate-100 max-h-[92%] overflow-y-auto text-left"
            >
              <div className="flex justify-between items-center mb-5 pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 bg-indigo-50 rounded-lg text-indigo-600">⚙️</span>
                  <h3 className="text-sm font-extrabold text-black uppercase tracking-wider">
                    {selectedLanguage === 'ES' ? 'Modificar Categoría' : 'Modify Category'}
                  </h3>
                </div>
                <button
                  onClick={() => { handleTap(); setShowManageCategories(false); }}
                  className="p-1.5 hover:bg-slate-100 rounded-full text-slate-400 transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* LIST OF CURRENT CATEGORIES */}
              <div className="space-y-2 mb-6">
                <h4 className="text-[10px] font-black uppercase tracking-wider text-slate-400 text-left">
                  {selectedLanguage === 'ES' ? 'Categorías Activas' : 'Active Categories'}
                </h4>
                <div className="grid grid-cols-1 gap-2 max-h-[220px] overflow-y-auto pr-1">
                  {categorias.map((c) => (
                    <div key={c.nombre} className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-150 rounded-xl">
                      <div className="flex items-center gap-2.5">
                        <div className="p-1.5 rounded-lg bg-white shadow-3xs">
                          {renderCategoriaIcon(c.icon, c.color, "w-4.5 h-4.5")}
                        </div>
                        <span className="text-xs font-extrabold text-slate-950">
                          {translateCategory(c.nombre)}
                        </span>
                      </div>

                      {c.nombre !== 'Otros' && (
                        <button
                          onClick={() => { handleTap(); handleDeleteCategory(c.nombre); }}
                          className="p-1.5 text-rose-500 hover:bg-rose-50 hover:text-rose-700 rounded-lg transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* ADD NEW CATEGORY PANEL */}
              <div className="border-t border-slate-100 pt-5 space-y-4">
                <h4 className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                  {selectedLanguage === 'ES' ? 'Agregar Nueva Categoría' : 'Add New Category'}
                </h4>

                <div>
                  <label className="text-[9px] font-black uppercase tracking-wider text-slate-500 mb-1 block">
                    {selectedLanguage === 'ES' ? 'Nombre de Categoría' : 'Category Name'}
                  </label>
                  <input
                    type="text"
                    maxLength={20}
                    placeholder={selectedLanguage === 'ES' ? 'Ej: Mascotas, Regalos...' : 'Ej: Pets, Gifts...'}
                    value={newCatName}
                    onChange={(e) => setNewCatName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                {/* ICON CHOOSE LIST */}
                <div>
                  <label className="text-[9px] font-black uppercase tracking-wider text-slate-500 mb-1 block">
                    {selectedLanguage === 'ES' ? 'Seleccionar Icono' : 'Select Icon'}
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {[
                      { key: 'Home', label: '🏠 Vivienda' },
                      { key: 'Utensils', label: '🍴 Comida' },
                      { key: 'Car', label: '🚗 Auto' },
                      { key: 'ShoppingBag', label: '🛍️ Compras' },
                      { key: 'Plane', label: '✈️ Viajes' },
                      { key: 'Sparkles', label: '✨ Especial' },
                      { key: 'Heart', label: '❤️ Mascota' },
                      { key: 'Scissors', label: '✂️ Moda' }
                    ].map((iconData) => {
                      const isSel = newCatIcon === iconData.key;
                      return (
                        <button
                          key={iconData.key}
                          type="button"
                          onClick={() => { handleTap(); setNewCatIcon(iconData.key); }}
                          className={`p-2 rounded-lg border text-xs font-bold flex flex-col items-center justify-center transition-all cursor-pointer ${
                            isSel ? 'border-indigo-650 bg-indigo-50 text-indigo-700 font-extrabold shadow-3xs' : 'border-slate-150 hover:bg-slate-50 text-slate-600'
                          }`}
                        >
                          <span className="text-sm shrink-0 mb-1">
                            {iconData.label.split(' ')[0]}
                          </span>
                          <span className="text-[8px] font-bold tracking-tight block truncate w-full">
                            {iconData.label.split(' ').slice(1).join(' ')}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* COLOR CHOOSER */}
                <div>
                  <label className="text-[9px] font-black uppercase tracking-wider text-slate-500 mb-1.5 block">
                    {selectedLanguage === 'ES' ? 'Color de Categoría' : 'Category Color'}
                  </label>
                  <div className="flex flex-wrap gap-2.5">
                    {[
                      '#8B5A2B', // Brown
                      '#F97316', // Orange
                      '#EF4444', // Red
                      '#EC4899', // Pink
                      '#3B82F6', // Blue
                      '#10B981', // Emerald
                      '#F43F5E', // Rose
                      '#9333EA', // Purple
                      '#14B8A6', // Teal
                      '#EAB308', // Yellow
                      '#6366F1'  // Indigo
                    ].map((col) => {
                      const isSel = newCatColor === col;
                      return (
                        <button
                          key={col}
                          type="button"
                          onClick={() => { handleTap(); setNewCatColor(col); }}
                          className={`w-6 h-6 rounded-full border transition-all cursor-pointer flex items-center justify-center ${
                            isSel ? 'ring-2 ring-indigo-650 scale-110 shadow-3xs border-white' : 'border-transparent hover:scale-105'
                          }`}
                          style={{ backgroundColor: col }}
                        >
                          {isSel && <Check className="w-3.5 h-3.5 text-white stroke-[3px]" />}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* CONFIRM ADD BUTTON */}
                <button
                  type="button"
                  onClick={handleAddCategory}
                  className="w-full py-3 bg-gradient-to-r from-teal-600 to-[#312E81] text-white font-black text-xs uppercase tracking-wider rounded-xl hover:opacity-95 shadow-lg active:scale-98 transition flex items-center justify-center gap-1.5 cursor-pointer mt-2"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>{selectedLanguage === 'ES' ? 'Confirmar Categoría' : 'Confirm Category'}</span>
                </button>
              </div>
            </motion.div>
          </>
        )}

        {isAddingOpen && (
          <>
            {/* Backdrop Overlay slider block */}
            <motion.div
              id="sheet-backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAddingOpen(false)}
              className="absolute inset-0 bg-black/60 z-40 backdrop-blur-[2px]"
            />

            {/* iOS Bottom Sheet Sheet core */}
            <motion.div
              id="movement-popup-sheet"
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 24, stiffness: 220 }}
              className="absolute bottom-0 inset-x-0 bg-white rounded-t-[30px] z-50 p-6 shadow-2xl flex flex-col border-t border-slate-100 max-h-[92%] overflow-hidden"
            >
              <div className="w-12 h-1.5 bg-gray-300 rounded-full mx-auto mb-4" />

              <div className="flex justify-between items-center mb-4">
                <h3 className="text-[17px] font-black text-slate-900 tracking-tight">Nuevo Movimiento</h3>
                <button
                  id="btn-sheet-close"
                  onClick={() => setIsAddingOpen(false)}
                  className="p-1.5 bg-gray-100 text-gray-500 rounded-full hover:bg-gray-200 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {popupInitialChoice === 'choice' ? (
                <div className="space-y-6 pt-2 pb-4 text-center">
                  <p className="text-xs font-semibold text-gray-500">¿Cómo deseas registrar tu nuevo movimiento?</p>
                  
                  <div className="grid grid-cols-2 gap-4">
                    {/* Manual Form Choice */}
                    <button
                      id="btn-choice-write"
                      type="button"
                      onClick={() => {
                        handleTap();
                        setPopupInitialChoice('form');
                      }}
                      className="p-5 rounded-2xl border border-slate-100 bg-slate-50/50 hover:bg-slate-100 flex flex-col items-center justify-center text-center cursor-pointer transition-all active:scale-95 duration-200"
                    >
                      <div className="p-3 bg-slate-900 text-white rounded-full mb-3 shadow-md">
                        <Sparkles className="w-6 h-6 text-indigo-400" />
                      </div>
                      <span className="text-xs font-extrabold text-slate-800">Escribir Manual</span>
                      <span className="text-[9px] text-gray-400 mt-1 block h-8 leading-relaxed">
                        Ingresa montos y detalles con el teclado
                      </span>
                    </button>

                    {/* Dictation Choice */}
                    <button
                      id="btn-choice-voice"
                      type="button"
                      onClick={() => {
                        handleTap();
                        setPopupInitialChoice('form');
                        setTimeout(() => {
                          setStartVoiceOnAdd(true);
                        }, 250);
                      }}
                      className="p-5 rounded-2xl border border-indigo-100 bg-indigo-50/20 hover:bg-indigo-50 flex flex-col items-center justify-center text-center cursor-pointer transition-all active:scale-95 duration-200"
                    >
                      <div className="p-3 bg-indigo-600 text-white rounded-full mb-3 shadow-[0_4px_10px_rgba(79,70,229,0.25)]">
                        <Mic className="w-6 h-6" />
                      </div>
                      <span className="text-xs font-extrabold text-slate-800">Dictar por Voz</span>
                      <span className="text-[9px] text-gray-400 mt-1 block h-8 leading-relaxed">
                        Habla y captura automáticamente el monto y categoría
                      </span>
                    </button>
                    
                    {/* Document Upload Choice */}
                    <input 
                      type="file" 
                      accept=".pdf,.csv,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,image/*"
                      style={{ display: 'none' }}
                      id="file-upload-input"
                      onChange={handleDocumentUpload}
                    />
                    <button
                      id="btn-choice-document"
                      type="button"
                      disabled={isUploadingDocument}
                      onClick={() => {
                        handleTap();
                        document.getElementById('file-upload-input')?.click();
                      }}
                      className="col-span-2 p-5 rounded-2xl border border-emerald-100 bg-emerald-50/20 hover:bg-emerald-50 flex flex-row items-center justify-center gap-4 text-center cursor-pointer transition-all active:scale-95 duration-200"
                    >
                      <div className="p-3 bg-emerald-600 text-white rounded-full shadow-[0_4px_10px_rgba(16,185,129,0.25)] shrink-0">
                        {isUploadingDocument ? <Loader2 className="w-6 h-6 animate-spin" /> : <Upload className="w-6 h-6" />}
                      </div>
                      <div className="flex flex-col text-left">
                        <span className="text-xs font-extrabold text-slate-800">Cargar Documento (PDF, Excel, Foto)</span>
                        <span className="text-[9px] text-gray-400 mt-1 leading-relaxed">
                          La inteligencia artificial leerá el monto, fecha y detalles automáticamente.
                        </span>
                      </div>
                    </button>
                    
                    {/* Sheets Upload Choice */}
                    <button
                      id="btn-choice-sheets"
                      type="button"
                      disabled={isImportingSheets}
                      onClick={() => {
                        handleTap();
                        importFromSheets();
                      }}
                      className="col-span-2 p-5 rounded-2xl border border-blue-100 bg-blue-50/20 hover:bg-blue-50 flex flex-row items-center justify-center gap-4 text-center cursor-pointer transition-all active:scale-95 duration-200 mt-[-10px]"
                    >
                      <div className="p-3 bg-blue-600 text-white rounded-full shadow-[0_4px_10px_rgba(37,99,235,0.25)] shrink-0">
                        {isImportingSheets ? <Loader2 className="w-6 h-6 animate-spin" /> : <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z"/></svg>}
                      </div>
                      <div className="flex flex-col text-left">
                        <span className="text-xs font-extrabold text-slate-800">Conectar Google Sheets</span>
                        <span className="text-[9px] text-gray-400 mt-1 leading-relaxed">
                          La IA extraerá y analizará el movimiento desde tu hoja de cálculo.
                        </span>
                      </div>
                    </button>
                  </div>

                  <button
                    id="btn-choice-cancel"
                    type="button"
                    onClick={() => setIsAddingOpen(false)}
                    className="w-full py-2.5 text-xs font-bold text-slate-500 bg-slate-100 hover:bg-slate-150 rounded-xl cursor-pointer mt-2"
                  >
                    Cerrar
                  </button>
                </div>
              ) : (
                              <TransactionForm
                startWithVoice={startVoiceOnAdd}
                onSave={(tx) => {
                  saveTransacciones([
                    { ...tx, id: `trx-${Date.now()}` },
                    ...transacciones
                  ]);
                  setIsAddingOpen(false);
                }}
                onCancel={() => { setIsAddingOpen(false); setStartVoiceOnAdd(false); }}
                getMergedPaymentMethods={getMergedPaymentMethods}
                CATEGORIAS_PREDEFINIDAS={CATEGORIAS_PREDEFINIDAS}
                categorias={categorias}
                COLOMBIAN_PRODUCTS={COLOMBIAN_PRODUCTS}
                translateProduct={translateProduct}
                selectedLanguage={selectedLanguage}
                renderCategoriaIcon={renderCategoriaIcon}
                triggerDynamicIsland={triggerDynamicIsland}
                playTone={playTone}
                isMuted={isMuted}
                formatLocalYYYYMMDD={formatLocalYYYYMMDD}
              />
            )}
          </motion.div>
          </>
        )}

        {editingTransaction && (
          <>
            {/* Backdrop Overlay slider block */}
            <motion.div
              id="edit-sheet-backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setEditingTransaction(null)}
              className="absolute inset-0 bg-black/60 z-45 backdrop-blur-[2px]"
            />

            {/* iOS Bottom Sheet Sheet core */}
            <motion.div
              id="edit-movement-popup-sheet"
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 24, stiffness: 220 }}
              className="absolute bottom-0 inset-x-0 bg-white rounded-t-[30px] z-50 p-6 shadow-2xl flex flex-col border-t border-slate-100 max-h-[92%] overflow-hidden"
            >
              <div className="w-12 h-1.5 bg-gray-300 rounded-full mx-auto mb-4 animate-pulse" />

              <div className="flex justify-between items-center mb-4 flex-shrink-0">
                <h3 className="text-[17px] font-black text-slate-900 tracking-tight">
                  {selectedLanguage === 'ES' ? 'Modificar Movimiento' : 'Modify Transaction'}
                </h3>
                <button
                  id="btn-edit-sheet-close"
                  onClick={() => setEditingTransaction(null)}
                  className="p-1.5 bg-gray-100 text-gray-500 rounded-full hover:bg-gray-200 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <TransactionForm
                key={editingTransaction.id}
                initialTransaction={editingTransaction}
                onSave={(updatedTx) => {
                  const updated: Transaccion = {
                    ...editingTransaction,
                    ...updatedTx
                  };
                  const updatedList = transacciones.map(t => t.id === editingTransaction.id ? updated : t);
                  saveTransacciones(updatedList);
                  setEditingTransaction(null);
                  playTone('success', isMuted);
                  triggerDynamicIsland(
                    selectedLanguage === 'ES' ? "Modificado con éxito" : "Modified successfully",
                    selectedLanguage === 'ES' ? "Movimiento de caja actualizado." : "Cashflow registry updated.",
                    true
                  );
                }}
                onCancel={() => setEditingTransaction(null)}
                getMergedPaymentMethods={getMergedPaymentMethods}
                CATEGORIAS_PREDEFINIDAS={CATEGORIAS_PREDEFINIDAS}
                categorias={categorias}
                COLOMBIAN_PRODUCTS={COLOMBIAN_PRODUCTS}
                translateProduct={translateProduct}
                selectedLanguage={selectedLanguage}
                renderCategoriaIcon={renderCategoriaIcon}
                triggerDynamicIsland={triggerDynamicIsland}
                playTone={playTone}
                isMuted={isMuted}
                formatLocalYYYYMMDD={formatLocalYYYYMMDD}
              />
            </motion.div>
          </>
        )}

        {editingPortafolio && (
          <>
            <motion.div
              id="edit-portafolio-backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setEditingPortafolio(null)}
              className="absolute inset-0 bg-black/60 z-45 backdrop-blur-[2px]"
            />
            <motion.div
              id="edit-portafolio-popup-sheet"
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 24, stiffness: 220 }}
              className="absolute bottom-0 inset-x-0 bg-white rounded-t-[30px] z-50 p-6 shadow-2xl flex flex-col border-t border-slate-100 max-h-[92%] overflow-hidden"
            >
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest">
                  {selectedLanguage === 'ES' ? 'Editar Activo' : 'Edit Asset'}
                </h3>
                <button
                  type="button"
                  onClick={() => setEditingPortafolio(null)}
                  className="p-2 bg-slate-100 rounded-full text-slate-500 hover:text-slate-800 transition"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSaveEditedPortafolio} className="flex-1 flex flex-col overflow-hidden min-h-0 text-left space-y-4">
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">{selectedLanguage === 'ES' ? 'Nombre del activo' : 'Asset Name'}</label>
                  <input type="text" value={editPortafolioNombre} onChange={e => setEditPortafolioNombre(e.target.value)} className="w-full mt-1 p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#00897B]/20 transition" required />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">{selectedLanguage === 'ES' ? 'Valor' : 'Value'}</label>
                  <input type="text" inputMode="numeric" value={editPortafolioValor} onChange={e => setEditPortafolioValor(e.target.value.replace(/[^0-9.]/g, ''))} className="w-full mt-1 p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#00897B]/20 transition" required />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">{selectedLanguage === 'ES' ? 'Plataforma / Banco' : 'Platform / Bank'}</label>
                  <input type="text" value={editPortafolioPlataforma} onChange={e => setEditPortafolioPlataforma(e.target.value)} className="w-full mt-1 p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#00897B]/20 transition" required />
                </div>

                <div className="flex gap-2.5 pt-3 border-t border-slate-100 bg-white mt-auto">
                  <button
                    type="button"
                    onClick={() => setEditingPortafolio(null)}
                    className="flex-1 py-3 text-xs font-black text-slate-600 bg-slate-100 hover:bg-slate-250 rounded-xl cursor-pointer text-center border border-slate-200"
                  >
                    {selectedLanguage === 'ES' ? 'Cancelar' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-3 text-xs font-black text-white bg-[#00897B] hover:bg-[#00796B] shadow-md shadow-teal-150 rounded-xl cursor-pointer text-center"
                  >
                    {selectedLanguage === 'ES' ? 'Guardar' : 'Save'}
                  </button>
                </div>
              </form>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};

  
  const handleBannerSignIn = async () => {
    const isIframe = window.self !== window.top;
    const isSandboxEnv = window.location.hostname.includes('run.app') || 
                         window.location.hostname.includes('localhost') || 
                         window.location.hostname.includes('webcontainer') ||
                         window.location.hostname.includes('aistudio') ||
                         isIframe;

    // In preview sandbox/iframes or run.app where Safari private mode blocks popups entirely,
    // intercept the click directly and show our beautiful guide or fake Google account chooser.
    if (isSandboxEnv) {
      setShowAuthGuide(true);
      return;
    }

    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    try {
      await signInWithPopup(auth, provider);
    } catch (popupError: any) {
      console.warn('Popup blocked, opening guide helper:', popupError);
      setShowAuthGuide(true);
    }
  };

  return (
    <div className="h-[100dvh] bg-[#0d0e14] flex flex-col justify-center items-center font-sans antialiased overflow-hidden">
      
      {/* Main Core Viewport Wrapper - Native feeling on mobile, clean preview on desktop screens */}
      <div className="w-full max-w-md h-[100dvh] md:min-h-0 md:h-[840px] md:max-h-[92vh] bg-[#f4f5f9] md:rounded-[40px] overflow-hidden shadow-2xl relative md:border md:border-slate-800/60 flex flex-col">
        
        {isLocalMode === true && !simulatedAuthMode && (
          <div className="bg-yellow-50 border-b border-yellow-200 px-4 py-3 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0 relative z-50 shadow-sm">
            <div className="flex items-start gap-2">
              <span className="text-yellow-600 mt-0.5">⚠️</span>
              <p className="text-[11px] text-yellow-800 font-medium leading-snug">
                FinDream está guardando datos localmente en tu dispositivo. <strong className="font-bold font-sans">Inicia sesión</strong> para habilitar el guardado automático de la nube.
                <button
                  type="button"
                  onClick={() => setShowAuthGuide(true)}
                  className="block text-[10px] text-yellow-700 underline mt-1 font-bold hover:text-yellow-900 cursor-pointer text-left"
                >
                  ¿No puedes iniciar sesión? Ver guía de ayuda
                </button>
              </p>
            </div>
            <button
              onClick={handleBannerSignIn}
              className="w-full sm:w-auto px-4 py-1.5 bg-yellow-600 hover:bg-yellow-700 active:scale-95 transition-all rounded-lg text-[11px] font-black tracking-wide text-white shadow-sm whitespace-nowrap uppercase cursor-pointer"
            >
              Iniciar sesión Google
            </button>
          </div>
        )}
        {renderAppContent()}
      </div>

      {/* --- PREMIUM CUSTOM iOS CONFIRMATION DIALOG (Guarantees iframe safety!) --- */}
      <AnimatePresence>
        {confirmDialog.isOpen && (
          <>
            {/* Backdrop overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setConfirmDialog(prev => ({ ...prev, isOpen: false }))}
              className="fixed inset-0 bg-black/60 z-[999] backdrop-blur-[2px] flex items-center justify-center p-4"
            >
              {/* Alert Card */}
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                transition={{ type: 'spring', damping: 25, stiffness: 350 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-white/95 backdrop-blur-md rounded-2xl max-w-[270px] w-full text-center shadow-2xl border border-gray-150 overflow-hidden"
              >
                <div className="p-5">
                  <h4 className="text-[16px] font-extrabold text-slate-900 leading-tight">
                    {confirmDialog.title}
                  </h4>
                  <p className="text-xs text-gray-500 mt-2 leading-relaxed">
                    {confirmDialog.message}
                  </p>
                </div>

                {/* Segmented iOS actions */}
                <div className="border-t border-gray-100 grid grid-cols-2">
                  <button
                    type="button"
                    onClick={() => { handleTap(); setConfirmDialog(prev => ({ ...prev, isOpen: false })); }}
                    className="py-3 px-4 text-sm font-semibold text-indigo-600 hover:bg-gray-50 active:bg-gray-100 border-r border-gray-100 transition-colors cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    type="button"
                    onClick={() => { handleTap(); confirmDialog.onConfirm(); }}
                    className="py-3 px-4 text-sm font-bold text-rose-600 hover:bg-rose-50 active:bg-rose-100 transition-colors cursor-pointer"
                  >
                    Confirmar
                  </button>
                </div>
              </motion.div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* --- GUIDE MODAL FOR AUTH ISSUES (Bypasses Safari/iframe blocks) --- */}
      <AnimatePresence>
        {showAuthGuide && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAuthGuide(false)}
              className="fixed inset-0 bg-black/75 z-[9999] backdrop-blur-[4px] flex items-center justify-center p-4"
            >
              <motion.div
                initial={{ scale: 0.95, y: 15 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.95, y: 15 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-[#12131a] border border-slate-800 rounded-3xl max-w-sm w-full p-6 text-slate-200 relative shadow-2xl overflow-hidden"
              >
                {/* Header */}
                <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-800/60">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">🔑</span>
                    <h3 className="text-[15px] font-bold text-white tracking-wide">
                      Guía del Inicio de Sesión
                    </h3>
                  </div>
                  <button
                    onClick={() => setShowAuthGuide(false)}
                    className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors cursor-pointer text-xs font-bold"
                  >
                    ✕
                  </button>
                </div>

                {/* Body Content */}
                <div className="space-y-4 text-xs leading-relaxed text-slate-300">
                  <p>
                    Para activar el almacenamiento en la nube, Google requiere validar tu cuenta. Por restricciones de seguridad del navegador, el login de Firebase se bloquea en marcos externos y navegación privada, mostrando una <strong>pantalla en blanco</strong>.
                  </p>

                  {/* Step 1 */}
                  <div className="flex gap-2.5 items-start bg-slate-900/40 p-2.5 rounded-xl border border-slate-800/65">
                    <span className="text-base mt-0.5">↗️</span>
                    <div>
                      <strong className="text-white block text-[11px] mb-0.5">1. Abre la App en Pestaña Nueva</strong>
                      <p className="text-[10px] text-slate-400">
                        Los iframes de AI Studio bloquean pantallas de login. Utiliza el botón de <strong>"Abrir en pestaña nueva ↗️"</strong> del panel superior derecho en AI Studio.
                      </p>
                    </div>
                  </div>

                  {/* Step 2 */}
                  <div className="flex gap-2.5 items-start bg-slate-900/40 p-2.5 rounded-xl border border-slate-800/65">
                    <span className="text-base mt-0.5">🕵️</span>
                    <div>
                      <strong className="text-white block text-[11px] mb-0.5">2. Desactiva Navegación Privada</strong>
                      <p className="text-[10px] text-slate-400">
                        El modo privado de Safari/Chrome bloquea las cookies de sesión temporal de Google. Usa una pestaña normal.
                      </p>
                    </div>
                  </div>

                  {/* Step 3: Public Link */}
                  <div className="bg-gradient-to-br from-indigo-950/30 to-indigo-900/10 p-3 rounded-xl border border-indigo-900/40 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-indigo-400 font-bold tracking-wider uppercase">Link Público Oficial</span>
                      <span className="text-[9px] bg-indigo-500/10 text-indigo-300 px-1.5 py-0.5 rounded-full font-semibold">Listo</span>
                    </div>
                    <div className="bg-black/30 p-2 rounded-lg border border-slate-800/60 text-[10px] font-mono select-all overflow-hidden break-all text-slate-300">
                      https://ais-pre-c7jzxend6cu3dx4cxlrbta-285412608330.us-east1.run.app
                    </div>

                    <button
                      onClick={async () => {
                        try {
                          await navigator.clipboard.writeText("https://ais-pre-c7jzxend6cu3dx4cxlrbta-285412608330.us-east1.run.app");
                          setCopiedLink(true);
                          setTimeout(() => setCopiedLink(false), 2000);
                        } catch (e) {
                          alert("Copia el link de arriba de manera manual de la casilla.");
                        }
                      }}
                      className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 active:scale-[0.98] transition-all text-white font-bold rounded-lg text-[11px] tracking-wide shadow-sm cursor-pointer"
                    >
                      {copiedLink ? '¡Enlace Copiado! ✓' : 'Copiar Enlace'}
                    </button>
                  </div>
                </div>

                {/* Try redirect fallback */}
                <div className="mt-4 pt-3 border-t border-slate-850 flex flex-col gap-2">
                  <p className="text-[10px] text-slate-400 text-center leading-normal">
                    ¿Problemas con el modo privado y la pantalla de carga?
                  </p>
                  
                  <button
                    onClick={async () => {
                      try {
                        const { signInAnonymously } = await import('firebase/auth');
                        await signInAnonymously(auth).catch(() => {});
                        
                        // Fake a profile to enable the rest of the app without full Google Auth
                        const fallbackProf = {
                          nombre: 'Prakash Dowlani',
                          correo: 'prakos@gmail.com',
                          celular: '3001234567',
                          productos: []
                        };
                        const existingReal = localStorage.getItem('finanza_user_profile_v2');
                        if (existingReal) {
                          try {
                            const parsed = JSON.parse(existingReal);
                            if (parsed && parsed.productos) {
                              fallbackProf.productos = parsed.productos;
                            }
                          } catch(e) {}
                        }
                        
                        localStorage.setItem('finanza_user_profile_v6_temp', JSON.stringify(fallbackProf));
                        localStorage.setItem('finanza_user_profile_v2', JSON.stringify(fallbackProf));
                        localStorage.setItem('findream_simulate_auth', 'true');
                        setSimulatedAuthMode(true);
                        setShowAuthGuide(false);
                        alert("¡Sesión Simulada (Perfil Local) Activada Exitosamente!");
                        window.location.reload();
                      } catch (e) {
                         alert("Error de sesión simulada.");
                      }
                    }}
                    className="w-full py-2 bg-gradient-to-r from-teal-600 to-teal-500 hover:from-teal-500 hover:to-teal-400 text-white rounded-lg text-[11px] font-bold transition-colors cursor-pointer shadow-md"
                  >
                    Simular Sesión Segura (Recomendado)
                  </button>

                  <button
                    onClick={async () => {
                      const provider = new GoogleAuthProvider();
                      try {
                        await signInWithRedirect(auth, provider);
                      } catch (e) {
                        alert("Error al intentar redirección: " + String(e));
                      }
                    }}
                    className="w-full py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-400 hover:text-white rounded-lg text-[10px] font-semibold transition-colors cursor-pointer"
                  >
                    Intentar redirección de Google
                  </button>
                </div>
              </motion.div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* --- MI CUENTA MODAL & COLOMBIAN BANK PRODUCTS --- */}
      <ProfileModal
        isCuentaOpen={isCuentaOpen}
        setIsCuentaOpen={setIsCuentaOpen}
        userProfile={userProfile}
        saveUserProfileData={saveUserProfileData}
        isBiometricRegistered={isBiometricRegistered}
        setIsBiometricRegistered={setIsBiometricRegistered}
        isEnrollingBiometrics={isEnrollingBiometrics}
        setIsEnrollingBiometrics={setIsEnrollingBiometrics}
        biometricEnrollMsg={biometricEnrollMsg}
        setBiometricEnrollMsg={setBiometricEnrollMsg}
        selectedLanguage={selectedLanguage}
        handleTap={handleTap}
        showAddProductSettings={showAddProductSettings}
        setShowAddProductSettings={setShowAddProductSettings}
        isMuted={isMuted}
        playTone={playTone}
        triggerDynamicIsland={triggerDynamicIsland}
        getProductUtilizado={getProductUtilizado}
        setActiveTab={setActiveTab}
        setShowSplash={setShowSplash}
      />

      <AnimatePresence>
        {showSplash && (
          <SplashIntro
            onComplete={() => setShowSplash(false)}
            isMuted={isMuted}
            onToggleMute={() => setIsMuted(!isMuted)}
            selectedLanguage={selectedLanguage}
          />
        )}
      </AnimatePresence>

    </div>
  );
}
